export interface Student {
  id: string;
  maqaaGuutuu: string;
  koorniyaa: 'Dhiira' | 'Dhalaa';
  kutaa: string;
  daree: string;
  baraDhalootaa: string;
  umurii: number;
  haalaGalmee: string;
  baraAddaanKute?: string;
  baraIrraDeebii?: string;
  haalaMaatii: string;
  miidhamaQaamaa: 'Eeyyee' | 'Lakkii';
  gosaMiidhamaa?: string;
  godina: string;
  aanaa: string;
  ganda: string;
  maqaaHaadhaa: string;
  fanId: string;
  nationalId: string;
  lakkBilbilaBarataa: string;
  lakkBilbilaMaatii: string;
  mbDuraan: string;
  avireejjiiQabxii: number | string;
  guyyaaGalmee: string;
  barsiisaaGalmeessee: string;
  manaBarumsaa: string;
}

export interface GradeTarget {
  kutaa: string;
  dhiira: number;
  dhalaa: number;
}

export interface LoginRecord {
  id: string;
  gmail: string;
  loginTime: string;
}

export interface SchoolSettings {
  savedSchoolName: string;
  baraBarnootaa: string;
}

export interface User {
  email: string;
  name: string;
  role: string;
}

export interface EMISStudent {
  nationalId?: string;
  fanId?: string;
  maqaaGuutuu: string;
  koorniyaa: string;
  kutaa: string;
  daree?: string;
  baraDhalootaa: string;
  umurii: number | string;
  avireejjiiQabxii?: number | string;
  godina?: string;
  aanaa?: string;
  ganda?: string;
  maqaaHaadhaa?: string;
  lakkBilbilaBarataa?: string;
  lakkBilbilaMaatii?: string;
  mbDuraan?: string;
  haalaMaatii?: string;
  miidhamaQaamaa?: string;
  gosaMiidhamaa?: string;
  fileSource?: 'BSD' | 'SR' | 'SE' | 'Merged BSD & SR';
  fileName?: string;
}

export interface EMISComparison {
  matches: Array<{ key: string; data: EMISStudent; national_id: string }>;
  mismatches: Array<{
    key: string;
    emis_data: EMISStudent;
    app_data: Student;
    mismatch_fields: Record<string, { emis: string; app: string }>;
    national_id: string;
  }>;
  emis_not_in_app: Array<{ key: string; data: EMISStudent; national_id: string }>;
  app_not_in_emis: Array<{ key: string; data: Student }>;
}

import { Student, GradeTarget, LoginRecord, SchoolSettings, EMISStudent } from '../types';
import {
  INITIAL_STUDENTS,
  INITIAL_TARGETS,
  INITIAL_SCHOOL_SETTINGS,
  INITIAL_EMIS_RECORDS,
  AUTHORIZED_USERS,
} from '../data/initialData';

const STORAGE_KEYS = {
  STUDENTS: 'kitesa_students_v1',
  TARGETS: 'kitesa_targets_v1',
  LOGINS: 'kitesa_logins_v1',
  SETTINGS: 'kitesa_settings_v1',
  CURRENT_USER: 'kitesa_current_user_v1',
  EMIS_RECORDS: 'kitesa_emis_records_v1',
  AUTH_USERS: 'kitesa_auth_users_v1',
  REVOKED_USERS: 'kitesa_revoked_users_v1',
  SCHOOLS_LIST: 'kitesa_schools_list_v1',
};

export const DEFAULT_SCHOOLS_LIST = [
  'Minaaree Sadarkaa 1ffaa',
  'Minaaree Sadarkaa 2ffaa',
  'Calalaqaa Sadarkaa 1ffaa',
];

export const getStoredRevokedUsers = (): string[] => {
  const data = localStorage.getItem(STORAGE_KEYS.REVOKED_USERS);
  if (!data) return [];
  try {
    const list = JSON.parse(data);
    return Array.isArray(list) ? list.map((e: string) => e.trim().toLowerCase()) : [];
  } catch (e) {
    return [];
  }
};

export const addRevokedUser = (email: string): void => {
  const cleanEmail = email.trim().toLowerCase();
  if (cleanEmail === 'kitesanegasa2012@gmail.com') return; // Creator cannot be revoked
  const current = getStoredRevokedUsers();
  if (!current.includes(cleanEmail)) {
    const updated = [...current, cleanEmail];
    localStorage.setItem(STORAGE_KEYS.REVOKED_USERS, JSON.stringify(updated));
  }
};

export const removeRevokedUser = (email: string): void => {
  const cleanEmail = email.trim().toLowerCase();
  const current = getStoredRevokedUsers();
  const updated = current.filter((e) => e !== cleanEmail);
  localStorage.setItem(STORAGE_KEYS.REVOKED_USERS, JSON.stringify(updated));
};

export const getStoredAuthorizedUsers = (): Record<string, string> => {
  const revoked = getStoredRevokedUsers();
  const data = localStorage.getItem(STORAGE_KEYS.AUTH_USERS);
  let baseUsers: Record<string, string> = { ...AUTHORIZED_USERS };
  if (data) {
    try {
      const parsed = JSON.parse(data);
      if (parsed && typeof parsed === 'object') {
        baseUsers = {
          'kitesanegasa2012@gmail.com': 'kitesanegasa2012password',
          ...parsed,
        };
      }
    } catch (e) {
      baseUsers = { ...AUTHORIZED_USERS };
    }
  } else {
    localStorage.setItem(STORAGE_KEYS.AUTH_USERS, JSON.stringify(AUTHORIZED_USERS));
  }

  // Filter out any revoked users
  const filtered: Record<string, string> = {};
  Object.keys(baseUsers).forEach((emailKey) => {
    const lower = emailKey.trim().toLowerCase();
    if (!revoked.includes(lower)) {
      filtered[emailKey] = baseUsers[emailKey];
    }
  });

  return filtered;
};

export const saveStoredAuthorizedUsers = (users: Record<string, string>): void => {
  localStorage.setItem(STORAGE_KEYS.AUTH_USERS, JSON.stringify(users));
};

export const getStoredSchoolsList = (): string[] => {
  const data = localStorage.getItem(STORAGE_KEYS.SCHOOLS_LIST);
  let list: string[] = DEFAULT_SCHOOLS_LIST;
  if (data) {
    try {
      list = JSON.parse(data);
    } catch (e) {
      list = DEFAULT_SCHOOLS_LIST;
    }
  }
  const cleaned = list.filter((s) => {
    if (!s) return false;
    const lower = s.toLowerCase();
    return !lower.includes('oda') && !lower.includes('bako');
  });
  return cleaned;
};

export const saveStoredSchoolsList = (schools: string[]): void => {
  const cleaned = schools.filter((s) => {
    if (!s) return false;
    const lower = s.toLowerCase();
    return !lower.includes('oda') && !lower.includes('bako');
  });
  localStorage.setItem(STORAGE_KEYS.SCHOOLS_LIST, JSON.stringify(cleaned));
};

export const getStoredStudents = (): Student[] => {
  const data = localStorage.getItem(STORAGE_KEYS.STUDENTS);
  let students: Student[] = INITIAL_STUDENTS;
  if (data) {
    try {
      students = JSON.parse(data);
    } catch (e) {
      console.error('Failed to parse students storage', e);
      students = INITIAL_STUDENTS;
    }
  }
  const cleaned = students.filter((st) => {
    const lower = (st.manaBarumsaa || '').toLowerCase();
    return !lower.includes('oda') && !lower.includes('bako');
  });
  return cleaned;
};

export const saveStoredStudents = (students: Student[]): void => {
  localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
};

export const getStoredTargets = (): Record<string, GradeTarget> => {
  const data = localStorage.getItem(STORAGE_KEYS.TARGETS);
  if (!data) {
    localStorage.setItem(STORAGE_KEYS.TARGETS, JSON.stringify(INITIAL_TARGETS));
    return INITIAL_TARGETS;
  }
  try {
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to parse targets storage', e);
    return INITIAL_TARGETS;
  }
};

export const saveStoredTargets = (targets: Record<string, GradeTarget>): void => {
  localStorage.setItem(STORAGE_KEYS.TARGETS, JSON.stringify(targets));
};

export const getStoredLogins = (): LoginRecord[] => {
  const data = localStorage.getItem(STORAGE_KEYS.LOGINS);
  if (!data) {
    const defaultLogins: LoginRecord[] = [
      { id: '1', gmail: 'kitesanegasa2012@gmail.com', loginTime: new Date().toISOString().replace('T', ' ').substring(0, 19) },
    ];
    localStorage.setItem(STORAGE_KEYS.LOGINS, JSON.stringify(defaultLogins));
    return defaultLogins;
  }
  try {
    return JSON.parse(data);
  } catch (e) {
    return [];
  }
};

export const addLoginRecord = (gmail: string): LoginRecord[] => {
  const logins = getStoredLogins();
  const newRecord: LoginRecord = {
    id: Date.now().toString(),
    gmail,
    loginTime: new Date().toLocaleString('en-US', { hour12: false }),
  };
  const updated = [newRecord, ...logins];
  localStorage.setItem(STORAGE_KEYS.LOGINS, JSON.stringify(updated));
  return updated;
};

export const deleteLoginRecord = (id: string): LoginRecord[] => {
  const logins = getStoredLogins();
  const updated = logins.filter((item) => item.id !== id);
  localStorage.setItem(STORAGE_KEYS.LOGINS, JSON.stringify(updated));
  return updated;
};

export const getStoredSettings = (): SchoolSettings => {
  const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
  if (!data) {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(INITIAL_SCHOOL_SETTINGS));
    return INITIAL_SCHOOL_SETTINGS;
  }
  try {
    return JSON.parse(data);
  } catch (e) {
    return INITIAL_SCHOOL_SETTINGS;
  }
};

export const saveStoredSettings = (settings: SchoolSettings): void => {
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
};

export const getStoredCurrentUser = (): string | null => {
  return localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
};

export const setStoredCurrentUser = (userEmail: string | null): void => {
  if (userEmail) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, userEmail);
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  }
};

export const getStoredEMISRecords = (): EMISStudent[] => {
  const data = localStorage.getItem(STORAGE_KEYS.EMIS_RECORDS);
  if (!data) {
    localStorage.setItem(STORAGE_KEYS.EMIS_RECORDS, JSON.stringify(INITIAL_EMIS_RECORDS));
    return INITIAL_EMIS_RECORDS;
  }
  try {
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to parse EMIS records storage', e);
    return INITIAL_EMIS_RECORDS;
  }
};

export const saveStoredEMISRecords = (records: EMISStudent[]): void => {
  localStorage.setItem(STORAGE_KEYS.EMIS_RECORDS, JSON.stringify(records));
};

// CSV Export Helper
export const exportToCSV = (filename: string, rows: object[]) => {
  if (!rows || !rows.length) return;
  const headers = Object.keys(rows[0]);
  const csvContent = [
    headers.join(','),
    ...rows.map((row) =>
      headers
        .map((field) => {
          const val = (row as Record<string, unknown>)[field] ?? '';
          return `"${String(val).replace(/"/g, '""')}"`;
        })
        .join(',')
    ),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

// Full System JSON Backup & Restore Helpers
export const exportFullBackupJSON = () => {
  const backupData = {
    version: '1.0',
    exportDate: new Date().toISOString(),
    students: getStoredStudents(),
    targets: getStoredTargets(),
    settings: getStoredSettings(),
    emisRecords: getStoredEMISRecords(),
    authUsers: getStoredAuthorizedUsers(),
    schoolsList: getStoredSchoolsList(),
  };

  const jsonStr = JSON.stringify(backupData, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const link = document.createElement('a');
  const filename = `Kitesa_System_Backup_${new Date().toISOString().slice(0, 10)}.json`;
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const mergeBackupJSON = (jsonString: string): { success: boolean; addedCount: number; totalCount: number; message: string } => {
  try {
    const data = JSON.parse(jsonString);
    let incomingStudents: Student[] = [];

    if (Array.isArray(data)) {
      incomingStudents = data;
    } else if (data && Array.isArray(data.students)) {
      incomingStudents = data.students;
    } else {
      return { success: false, addedCount: 0, totalCount: 0, message: 'Fayiliin JSON gadi buufame sirrii miti ykn ragaa barattootaa hin qabu!' };
    }

    const currentStudents = getStoredStudents();
    const existingIds = new Set(currentStudents.map((s) => s.id));
    const existingKeys = new Set(
      currentStudents.map((s) =>
        `${(s.maqaaGuutuu || '').trim().toLowerCase()}_${(s.kutaa || '').trim().toLowerCase()}_${(s.manaBarumsaa || '').trim().toLowerCase()}`
      )
    );

    let addedCount = 0;
    const newStudentList = [...currentStudents];

    incomingStudents.forEach((st) => {
      const compositeKey = `${(st.maqaaGuutuu || '').trim().toLowerCase()}_${(st.kutaa || '').trim().toLowerCase()}_${(st.manaBarumsaa || '').trim().toLowerCase()}`;
      if (!existingIds.has(st.id) && !existingKeys.has(compositeKey)) {
        newStudentList.push(st);
        existingIds.add(st.id);
        existingKeys.add(compositeKey);
        addedCount++;
      }
    });

    if (addedCount > 0) {
      saveStoredStudents(newStudentList);
    }

    // Merge authUsers if present
    if (data.authUsers && typeof data.authUsers === 'object') {
      const currentAuth = getStoredAuthorizedUsers();
      const mergedAuth = { ...currentAuth, ...data.authUsers };
      saveStoredAuthorizedUsers(mergedAuth);
    }

    // Merge schoolsList if present
    if (data.schoolsList && Array.isArray(data.schoolsList)) {
      const currentSchools = getStoredSchoolsList();
      const combined = Array.from(new Set([...currentSchools, ...data.schoolsList]));
      saveStoredSchoolsList(combined);
    }

    return {
      success: true,
      addedCount,
      totalCount: newStudentList.length,
      message: `✓ Barattoonni haaraa [${addedCount}] bilbila/kompuutara biraa irraa galmee keessanitti walitti makamaniiru! Walumaagalatti barattoonni [${newStudentList.length}] galmaa'aniiru.`,
    };
  } catch (e) {
    console.error('Failed to merge backup JSON', e);
    return { success: false, addedCount: 0, totalCount: 0, message: 'Dogoggora: Fayilii JSON walitti makuun hin danda’amne!' };
  }
};

export const importFullBackupJSON = (jsonString: string): boolean => {
  try {
    const data = JSON.parse(jsonString);
    if (data.students && Array.isArray(data.students)) {
      saveStoredStudents(data.students);
    }
    if (data.targets && typeof data.targets === 'object') {
      saveStoredTargets(data.targets);
    }
    if (data.settings && typeof data.settings === 'object') {
      saveStoredSettings(data.settings);
    }
    if (data.emisRecords && Array.isArray(data.emisRecords)) {
      saveStoredEMISRecords(data.emisRecords);
    }
    if (data.authUsers && typeof data.authUsers === 'object') {
      saveStoredAuthorizedUsers(data.authUsers);
    }
    if (data.schoolsList && Array.isArray(data.schoolsList)) {
      saveStoredSchoolsList(data.schoolsList);
    }
    return true;
  } catch (e) {
    console.error('Failed to import full backup JSON', e);
    return false;
  }
};



import React from 'react';
import { Student, GradeTarget, SchoolSettings } from '../types';
import { ContactCard } from './ContactCard';
import { Users, UserCheck, Heart, Award, Target, School } from 'lucide-react';

interface DashboardProps {
  students: Student[];
  targets: Record<string, GradeTarget>;
  settings: SchoolSettings;
  onNavigate: (tab: string) => void;
  allSchools?: string[];
  selectedSchoolFilter?: string;
  onSelectSchoolFilter?: (school: string) => void;
  onOpenPostcard?: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  students,
  targets,
  settings,
  onNavigate,
  allSchools = [],
  selectedSchoolFilter: externalSchoolFilter,
  onSelectSchoolFilter,
  onOpenPostcard,
}) => {
  const [internalSchoolFilter, setInternalSchoolFilter] = React.useState<string>(settings.savedSchoolName || 'ALL_WOREDA');
  const [isWoredaUnlocked, setIsWoredaUnlocked] = React.useState<boolean>(true);
  const [isLockModalOpen, setIsLockModalOpen] = React.useState<boolean>(false);
  const [pendingSchoolChange, setPendingSchoolChange] = React.useState<string | null>(null);

  // Section Lock States
  const [isReportFilterUnlocked, setIsReportFilterUnlocked] = React.useState<boolean>(false);
  const [reportFilterPassInput, setReportFilterPassInput] = React.useState<string>('');

  const [isSchoolsListUnlocked, setIsSchoolsListUnlocked] = React.useState<boolean>(false);
  const [schoolsListPassInput, setSchoolsListPassInput] = React.useState<string>('');

  const verifyPasscode = (pass: string): boolean => {
    const clean = pass.trim().toUpperCase();
    return (
      clean === 'LATI' ||
      clean === 'LAATI' ||
      clean === 'SRS@2026#$K' ||
      clean === 'KITESANAGASA2012PASSWORD' ||
      clean === '1234'
    );
  };

  const handleUnlockReportFilter = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyPasscode(reportFilterPassInput)) {
      setIsReportFilterUnlocked(true);
      setReportFilterPassInput('');
    } else {
      alert('❌ Jecha Darbiisaa (Password) dogoggoraa!');
    }
  };

  const handleUnlockSchoolsList = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyPasscode(schoolsListPassInput)) {
      setIsSchoolsListUnlocked(true);
      setSchoolsListPassInput('');
    } else {
      alert('❌ Jecha Darbiisaa (Password) dogoggoraa!');
    }
  };

  const selectedSchoolFilter = externalSchoolFilter ?? internalSchoolFilter;

  const applySchoolFilter = (school: string) => {
    setInternalSchoolFilter(school);
    if (onSelectSchoolFilter) {
      onSelectSchoolFilter(school);
    }
  };

  const handleSchoolChangeRequest = (school: string) => {
    applySchoolFilter(school);
  };

  const handleModalUnlocked = () => {
    setIsWoredaUnlocked(true);
    setIsLockModalOpen(false);
    if (pendingSchoolChange) {
      applySchoolFilter(pendingSchoolChange);
      setPendingSchoolChange(null);
    }
  };

  // Combined schools list including configured settings school
  const combinedSchoolsList = Array.from(
    new Set([
      ...(settings.savedSchoolName ? [settings.savedSchoolName] : []),
      ...allSchools,
      ...students.map((s) => s.manaBarumsaa).filter((s) => s && s.trim() !== ''),
    ])
  );

  // Filter students (if locked and ALL_WOREDA selected, default to savedSchoolName)
  const effectiveFilter = (!isWoredaUnlocked && selectedSchoolFilter === 'ALL_WOREDA')
    ? (settings.savedSchoolName || 'ALL_WOREDA')
    : selectedSchoolFilter;

  const filteredStudents =
    effectiveFilter === 'ALL_WOREDA'
      ? students
      : students.filter((s) => s.manaBarumsaa === effectiveFilter);

  const totalStudents = filteredStudents.length;
  const maleStudents = filteredStudents.filter((s) => s.koorniyaa === 'Dhiira').length;
  const femaleStudents = filteredStudents.filter((s) => s.koorniyaa === 'Dhalaa').length;
  const disabledStudents = filteredStudents.filter((s) => s.miidhamaQaamaa === 'Eeyyee').length;

  // Grade breakdown
  const gradesList = Array.from({ length: 12 }, (_, i) => String(i + 1));
  const gradeCounts = gradesList.map((g) => {
    const inGrade = filteredStudents.filter((s) => s.kutaa === g);
    const dhiira = inGrade.filter((s) => s.koorniyaa === 'Dhiira').length;
    const dhalaa = inGrade.filter((s) => s.koorniyaa === 'Dhalaa').length;
    const target = targets[g] ? targets[g].dhiira + targets[g].dhalaa : 0;
    return {
      grade: g,
      total: inGrade.length,
      dhiira,
      dhalaa,
      target,
    };
  });

  // Calculate overall target vs actual
  const totalTarget = (Object.values(targets) as GradeTarget[]).reduce((acc, t) => acc + (t.dhiira || 0) + (t.dhalaa || 0), 0);
  const targetPct = totalTarget > 0 ? ((totalStudents / totalTarget) * 100).toFixed(1) : '0';

  return (
    <div className="space-y-6">
      
      {/* Cover / Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-purple-950 p-8 text-white shadow-2xl border-2 border-amber-400/40">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
          <div className="space-y-2 max-w-2xl">
            <span className="inline-block px-3 py-1 bg-amber-400/20 text-amber-300 border border-amber-400/40 text-xs font-bold rounded-full uppercase tracking-widest">
              ✨ Student Management System
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              Baga Nagaan Dhuftan!
            </h2>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Systema Galmee Barattootaa fi Odeeffannoo EMIS - {selectedSchoolFilter === 'ALL_WOREDA' ? settings.savedSchoolName : selectedSchoolFilter} - Bara {settings.baraBarnootaa}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            {onOpenPostcard && (
              <button
                type="button"
                onClick={onOpenPostcard}
                className="px-5 py-3 bg-gradient-to-r from-purple-500 via-pink-500 to-amber-400 hover:from-purple-400 hover:to-amber-300 text-white font-black rounded-2xl shadow-xl transition transform hover:-translate-y-0.5 cursor-pointer text-sm flex items-center justify-center gap-2 border border-purple-300/40"
              >
                <span className="text-base">🎴</span>
                <span>Qabiyyee Appii (10)</span>
              </button>
            )}
            <button
              onClick={() => onNavigate('students')}
              className="px-6 py-3 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 text-slate-900 font-bold rounded-2xl shadow-lg transition transform hover:-translate-y-0.5 cursor-pointer text-sm"
            >
              ➕ Barataa Haaraa Galmeessi
            </button>
            <button
              onClick={() => onNavigate('reports')}
              className="px-6 py-3 bg-slate-800/80 hover:bg-slate-700 border border-indigo-700/60 text-white font-semibold rounded-2xl transition cursor-pointer text-sm"
            >
              📄 Gabaasa Ilaali
            </button>
          </div>
        </div>
      </div>

      {/* Woreda vs Individual School Filter Selector Bar */}
      <div className="bg-white p-4.5 rounded-2xl border-2 border-indigo-200 shadow-md flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-indigo-600 to-slate-900 text-amber-400 rounded-2xl shadow-sm shrink-0 border border-indigo-400">
            <School className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-slate-900 text-sm sm:text-base">
                Filannoo Sadarkaa Gabaasaa maanneen barnoota
              </h3>
              {!isReportFilterUnlocked && (
                <span className="text-xs text-amber-800 bg-amber-50 px-2.5 py-1 rounded-lg font-extrabold border border-amber-200">
                  🔒 Cufamaa (Locked)
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 font-medium">
              tokko tokkoo ragaalee manneen barnoota calalalanii ilaaluuf:
            </p>
          </div>
        </div>

        {!isReportFilterUnlocked ? (
          <form onSubmit={handleUnlockReportFilter} className="flex items-center gap-2 w-full md:w-auto">
            <input
              type="password"
              required
              placeholder="Jecha darbiisaa saaqi..."
              value={reportFilterPassInput}
              onChange={(e) => setReportFilterPassInput(e.target.value)}
              className="p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono focus:ring-2 focus:ring-indigo-500 w-full sm:w-60"
            />
            <button
              type="submit"
              className="px-4 py-2.5 bg-indigo-900 hover:bg-slate-900 text-amber-300 font-bold rounded-xl text-xs transition cursor-pointer whitespace-nowrap"
            >
              🔓 Saaqi
            </button>
          </form>
        ) : (
          <div className="w-full md:w-auto flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="flex items-center gap-2 w-full md:w-auto">
              <label className="text-xs font-bold text-slate-700 whitespace-nowrap">Ilaali:</label>
              <div className="relative w-full md:w-72">
                <select
                  value={selectedSchoolFilter}
                  onChange={(e) => handleSchoolChangeRequest(e.target.value)}
                  className="w-full p-2.5 rounded-xl font-bold text-xs border-2 transition focus:ring-2 cursor-pointer bg-emerald-50/60 border-emerald-400 text-slate-900 focus:ring-emerald-500"
                >
                  <option value="ALL_WOREDA">
                    🏢 Manneen Barnootaa Hunda Waliigala
                  </option>
                  {combinedSchoolsList.map((sch) => (
                    <option key={sch} value={sch}>
                      🏫 {sch}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total Students */}
        <div className="bg-white p-6 rounded-2xl border-2 border-slate-200 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Waliigala Barattootaa
            </span>
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <h2 className="text-3xl font-extrabold text-blue-600 mb-1">{totalStudents}</h2>
          <p className="text-xs text-slate-500">Total Registered Students</p>
        </div>

        {/* Male Students */}
        <div className="bg-white p-6 rounded-2xl border-2 border-slate-200 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Dhiira (Male)
            </span>
            <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center font-bold">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
          <h2 className="text-3xl font-extrabold text-sky-600 mb-1">{maleStudents}</h2>
          <p className="text-xs text-slate-500">
            {totalStudents > 0 ? `${((maleStudents / totalStudents) * 100).toFixed(1)}% of total` : '0%'}
          </p>
        </div>

        {/* Female Students */}
        <div className="bg-white p-6 rounded-2xl border-2 border-slate-200 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Dhalaa (Female)
            </span>
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center font-bold">
              <Heart className="w-5 h-5" />
            </div>
          </div>
          <h2 className="text-3xl font-extrabold text-rose-600 mb-1">{femaleStudents}</h2>
          <p className="text-xs text-slate-500">
            {totalStudents > 0 ? `${((femaleStudents / totalStudents) * 100).toFixed(1)}% of total` : '0%'}
          </p>
        </div>

        {/* Target Progress */}
        <div className="bg-white p-6 rounded-2xl border-2 border-slate-200 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Raawwii Karooraa
            </span>
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold">
              <Target className="w-5 h-5" />
            </div>
          </div>
          <h2 className="text-3xl font-extrabold text-emerald-600 mb-1">{targetPct}%</h2>
          <p className="text-xs text-slate-500">
            Target: {totalTarget} | Actual: {totalStudents}
          </p>
        </div>

      </div>

      {/* Grade Level Summary Table / Visual Progress */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Award className="w-5 h-5 text-indigo-600" />
              <span>Raawwii Kutaa Kutaadhaan (Grade Level Distribution)</span>
            </h3>
            <p className="text-xs text-slate-500">Baay'ina barattoota kutaa 1 - 12</p>
          </div>
          <button
            onClick={() => onNavigate('targets')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 underline"
          >
            Karoora Jijjiiri →
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {/* Bu'uura Boruu (Umurii 4-6) Card */}
          {(() => {
            const bbStudents = filteredStudents.filter(
              (s) => s.kutaa === '0' || (s.kutaa || '').toLowerCase().includes('buuura') || (s.kutaa || '').toLowerCase().includes('borru')
            );
            const bbTotal = bbStudents.length;
            const bbTarget = (targets['bb_4']?.dhiira || 0) + (targets['bb_4']?.dhalaa || 0) +
                             (targets['bb_5']?.dhiira || 0) + (targets['bb_5']?.dhalaa || 0) +
                             (targets['bb_6']?.dhiira || 0) + (targets['bb_6']?.dhalaa || 0) || 50;
            const bbPct = bbTarget > 0 ? Math.min(100, Math.round((bbTotal / bbTarget) * 100)) : 0;

            return (
              <div
                onClick={() => onNavigate('buuura_boruu')}
                className="p-4 bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-300 rounded-xl hover:border-amber-500 transition cursor-pointer shadow-xs"
              >
                <div className="flex justify-between items-start mb-1">
                  <span className="text-xs font-black text-amber-950">Bu'uura Boruu</span>
                  <span className="text-[10px] bg-amber-200 text-amber-900 font-bold px-1.5 py-0.5 rounded-full">
                    {bbPct}%
                  </span>
                </div>
                <div className="text-2xl font-black text-slate-900">{bbTotal}</div>
                <div className="text-[10px] text-slate-600 font-semibold mt-1">
                  D: {bbStudents.filter((s) => s.koorniyaa === 'Dhiira').length} | Dh: {bbStudents.filter((s) => s.koorniyaa === 'Dhalaa').length}
                </div>
                <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className="bg-amber-500 h-1.5 rounded-full"
                    style={{ width: `${bbPct}%` }}
                  />
                </div>
              </div>
            );
          })()}

          {gradeCounts.map((g) => {
            const pct = g.target > 0 ? Math.min(100, Math.round((g.total / g.target) * 100)) : 0;
            return (
              <div
                key={g.grade}
                className="p-4 bg-slate-50 border border-slate-200 rounded-xl hover:border-indigo-300 transition"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-slate-800 text-sm">Kutaa {g.grade}</span>
                  <span className="text-xs font-semibold text-indigo-600">{g.total}</span>
                </div>

                <div className="flex justify-between text-[11px] text-slate-500 mb-2">
                  <span>👨 {g.dhiira}</span>
                  <span>👩 {g.dhalaa}</span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <div className="text-[10px] text-slate-400 mt-1 text-right font-mono">
                  Target: {g.target} ({pct}%)
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Woreda Schools Breakdown Table (Shows summary of each school in the district) */}
      <div className="bg-white rounded-2xl border-2 border-indigo-100 shadow-sm p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
          <div>
            <span className="text-[11px] font-bold text-indigo-600 uppercase tracking-widest">
              Gabaasa waligalaa manneen barnootaa
            </span>
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <School className="w-5 h-5 text-indigo-600" />
              <span>Baayyina Manneen Barnootaa ({combinedSchoolsList.length})</span>
              {!isSchoolsListUnlocked && (
                <span className="text-xs text-amber-800 bg-amber-50 px-2.5 py-1 rounded-lg font-extrabold border border-amber-200">
                  🔒 Cufamaa (Locked)
                </span>
              )}
            </h3>
          </div>
          <span className="text-xs font-semibold px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full border border-indigo-200 self-start sm:self-auto">
            Waliigala Barattoota Manneen Barnootaa: {students.length}
          </span>
        </div>

        {!isSchoolsListUnlocked ? (
          <form onSubmit={handleUnlockSchoolsList} className="p-6 bg-slate-50 rounded-2xl border border-slate-200 text-center max-w-md mx-auto space-y-3">
            <div className="w-12 h-12 bg-indigo-100 text-indigo-800 rounded-full flex items-center justify-center mx-auto font-black text-xl">
              🔒
            </div>
            <h4 className="text-sm font-extrabold text-slate-900">
              Tarree Manneen Barnootaa Ilaaluuf Jecha Darbiisaa (Password) Seensisaa
            </h4>
            <div className="flex items-center gap-2">
              <input
                type="password"
                required
                placeholder="Jecha darbiisaa saaqi..."
                value={schoolsListPassInput}
                onChange={(e) => setSchoolsListPassInput(e.target.value)}
                className="p-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono focus:ring-2 focus:ring-indigo-500 grow"
              />
              <button
                type="submit"
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition cursor-pointer whitespace-nowrap"
              >
                🔓 Saaqi
              </button>
            </div>
          </form>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-100/80 text-slate-900 uppercase font-bold text-[11px] border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Lakk.</th>
                  <th className="px-4 py-3">Maqaa Mana Barumsaa</th>
                  <th className="px-4 py-3 text-center">Dhiira</th>
                  <th className="px-4 py-3 text-center">Dhalaa</th>
                  <th className="px-4 py-3 text-center">Miidhama Qaamaa</th>
                  <th className="px-4 py-3 text-center">Waliigala Barattootaa</th>
                  <th className="px-4 py-3 text-right">Tarkaanfii</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {combinedSchoolsList.map((schName, idx) => {
                  const schStudents = students.filter((s) => s.manaBarumsaa === schName);
                  const schM = schStudents.filter((s) => s.koorniyaa === 'Dhiira').length;
                  const schF = schStudents.filter((s) => s.koorniyaa === 'Dhalaa').length;
                  const schDis = schStudents.filter((s) => s.miidhamaQaamaa === 'Eeyyee').length;

                  return (
                    <tr key={schName} className="hover:bg-slate-50 transition">
                      <td className="px-4 py-3 font-semibold text-slate-400">{idx + 1}</td>
                      <td className="px-4 py-3 font-bold text-slate-900 flex items-center gap-2">
                        <School className="w-4 h-4 text-indigo-500" />
                        <span>{schName}</span>
                        {schName === settings.savedSchoolName && (
                          <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded-full border border-amber-300">
                            M/B Keessan
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-center font-semibold text-sky-600">{schM}</td>
                      <td className="px-4 py-3 text-center font-semibold text-rose-600">{schF}</td>
                      <td className="px-4 py-3 text-center font-semibold text-purple-600">{schDis}</td>
                      <td className="px-4 py-3 text-center font-extrabold text-indigo-900 bg-indigo-50/50 rounded-lg">
                        {schStudents.length}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => handleSchoolChangeRequest(schName)}
                          className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg transition text-[11px]"
                        >
                          Calali (Filter)
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Quick Statistics Banner & Contact Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Special Needs & Demographics Card */}
        <div className="lg:col-span-2 bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-2xl p-6 shadow-md border border-indigo-800 flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
              Barattoota Miidhama Qaamaa Qaban
            </span>
            <h3 className="text-xl font-extrabold text-white mt-1 mb-3">
              Special Needs & Inclusion Overview
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-4">
              <div className="p-4 bg-indigo-950/70 border border-indigo-700/60 rounded-xl">
                <p className="text-xs text-slate-300">Waliigala Miidhama Qaamaa</p>
                <p className="text-2xl font-bold text-amber-400 mt-1">{disabledStudents} Barattoota</p>
                <p className="text-[11px] text-slate-400 mt-1">
                  {totalStudents > 0 ? `${((disabledStudents / totalStudents) * 100).toFixed(1)}% of all registered` : '0%'}
                </p>
              </div>
              <div className="p-4 bg-indigo-950/70 border border-indigo-700/60 rounded-xl">
                <p className="text-xs text-slate-300">Mana Barumsaa Ammee</p>
                <p className="text-lg font-bold text-white mt-1 truncate" title={settings.savedSchoolName}>
                  {settings.savedSchoolName}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">Bara Barnootaa: {settings.baraBarnootaa}</p>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-indigo-800 flex items-center justify-between text-xs text-slate-300">
            <span className="flex items-center gap-1">
              <School className="w-4 h-4 text-amber-400" /> Systema Galmee Kitesa Negasa Feyisa
            </span>
            <button
              onClick={() => onNavigate('settings')}
              className="text-amber-300 font-semibold hover:underline"
            >
              Qindaa'ina Jijjiiri →
            </button>
          </div>
        </div>

        {/* Author Contact Card */}
        <ContactCard />

      </div>

    </div>
  );
};

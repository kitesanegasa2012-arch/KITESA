import React, { useState } from 'react';
import { Student, SchoolSettings, GradeTarget } from '../types';
import { exportToCSV } from '../utils/storage';
import { HAALA_GALMEE_OPTIONS } from './StudentRegistration';
import {
  FileText,
  Printer,
  Download,
  Filter,
  Lock,
  CheckCircle2,
  Table,
  Target,
  Users,
  Calendar,
  Layers,
  HeartHandshake,
  BarChart3,
  RotateCcw,
  PieChart,
  Award,
  Edit2,
  Trash2,
  Search,
  Eye,
} from 'lucide-react';

interface ReportsProps {
  students: Student[];
  targets: Record<string, GradeTarget>;
  onSaveTargets: (newTargets: Record<string, GradeTarget>) => void;
  settings: SchoolSettings;
  onUpdateStudent?: (updatedStudent: Student) => void;
  onDeleteStudent?: (id: string) => void;
}

export type ReportTabKey =
  | 'tabA_karoora'
  | 'tabB_waligalaa'
  | 'tabC_guyyaa'
  | 'tabD_galmee_dheeraa'
  | 'tabE_miidhama_roster'
  | 'tabF_miidhama_summary'
  | 'tabG_irra_deebii_roster'
  | 'tabH_irra_deebii_summary'
  | 'tabI_karoora_raawwii';

export const Reports: React.FC<ReportsProps> = ({
  students,
  targets,
  onSaveTargets,
  settings,
}) => {
  const [activeTab, setActiveTab] = useState<ReportTabKey>('tabI_karoora_raawwii');

  // Filter / Search inside reports
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedKebele, setSelectedKebele] = useState('ALL');
  const [selectedGrade, setSelectedGrade] = useState('ALL');
  const [reportAgeFilter, setReportAgeFilter] = useState<'ALL' | '7' | '4_6' | '8_plus'>('ALL');
  const [reportSortOrder, setReportSortOrder] = useState<'AZ' | 'ZA' | 'DEFAULT'>('AZ');

  // Local state for Tab A editing
  const [editingTargets, setEditingTargets] = useState<Record<string, GradeTarget>>(targets);
  const [targetSuccessMsg, setTargetSuccessMsg] = useState(false);

  // Filter students based on current school, age filter, and sort order
  const baseSchoolStudents = students.filter(
    (s) => !settings.savedSchoolName || s.manaBarumsaa === settings.savedSchoolName || s.manaBarumsaa === ''
  );

  const schoolStudents = baseSchoolStudents
    .filter((s) => {
      if (reportAgeFilter === '7') return s.umurii === 7;
      if (reportAgeFilter === '4_6') return s.umurii >= 4 && s.umurii <= 6;
      if (reportAgeFilter === '8_plus') return s.umurii >= 8;
      return true;
    })
    .sort((a, b) => {
      if (reportSortOrder === 'AZ') return a.maqaaGuutuu.localeCompare(b.maqaaGuutuu);
      if (reportSortOrder === 'ZA') return b.maqaaGuutuu.localeCompare(a.maqaaGuutuu);
      return 0;
    });

  const todayStr = new Date().toISOString().split('T')[0];
  const todayFormatted = new Date().toLocaleDateString('en-GB');

  // Print helper
  const handlePrint = () => {
    window.print();
  };

  // Targets handler for Tab A
  const handleTargetChange = (grade: string, field: 'dhiira' | 'dhalaa', value: number) => {
    const updated = {
      ...editingTargets,
      [grade]: {
        kutaa: grade,
        dhiira: field === 'dhiira' ? value : editingTargets[grade]?.dhiira || 0,
        dhalaa: field === 'dhalaa' ? value : editingTargets[grade]?.dhalaa || 0,
      },
    };
    setEditingTargets(updated);
  };

  const handleSaveTargetsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveTargets(editingTargets);
    setTargetSuccessMsg(true);
    setTimeout(() => setTargetSuccessMsg(false), 3000);
  };

  // Common Grade Counts Helper with Cycle Subtotals (Bu'uura Boruu Umurii 4, 5, 6 & Total 4-6, 1-6, 7-8, 1-8, 9-12, 1-12)
  const getStructuredGradeStats = (customStudentsList = schoolStudents) => {
    const bbStudents = customStudentsList.filter(
      (s) => s.kutaa === '0' || (s.kutaa || '').toLowerCase().includes('buuura') || (s.kutaa || '').toLowerCase().includes('borru')
    );

    // Age breakdown for Bu'uura Boruu
    const bb4 = bbStudents.filter((s) => s.umurii === 4);
    const bb5 = bbStudents.filter((s) => s.umurii === 5);
    const bb6 = bbStudents.filter((s) => s.umurii === 6);

    const makeBbRow = (key: string, label: string, list: typeof bbStudents, targetKey: string) => {
      const dhiira = list.filter((s) => s.koorniyaa === 'Dhiira').length;
      const dhalaa = list.filter((s) => s.koorniyaa === 'Dhalaa').length;
      const target = targets[targetKey] || { dhiira: 15, dhalaa: 15, kutaa: targetKey };
      const targetTotal = target.dhiira + target.dhalaa;
      const total = dhiira + dhalaa;

      return {
        key,
        kutaa: label,
        gradeNumber: 0,
        dhiira,
        dhalaa,
        total,
        targetDhiira: target.dhiira,
        targetDhalaa: target.dhalaa,
        targetTotal,
        pctDhiira: target.dhiira > 0 ? parseFloat(((dhiira / target.dhiira) * 100).toFixed(1)) : 0,
        pctDhalaa: target.dhalaa > 0 ? parseFloat(((dhalaa / target.dhalaa) * 100).toFixed(1)) : 0,
        pctTotal: targetTotal > 0 ? parseFloat(((total / targetTotal) * 100).toFixed(1)) : 0,
        pct: targetTotal > 0 ? parseFloat(((total / targetTotal) * 100).toFixed(1)) : 0,
        isSubtotal: false,
        isGrandTotal: false,
      };
    };

    const rowBb4 = makeBbRow('bb_u4', "Bu'uura Boruu - Umurii 4", bb4, 'bb_4');
    const rowBb5 = makeBbRow('bb_u5', "Bu'uura Boruu - Umurii 5", bb5, 'bb_5');
    const rowBb6 = makeBbRow('bb_u6', "Bu'uura Boruu - Umurii 6", bb6, 'bb_6');

    // Subtotal for Bu'uura Boruu (Umurii 4-6)
    const bbDhiira = bbStudents.filter((s) => s.koorniyaa === 'Dhiira').length;
    const bbDhalaa = bbStudents.filter((s) => s.koorniyaa === 'Dhalaa').length;
    const bbTargetDhiira = rowBb4.targetDhiira + rowBb5.targetDhiira + rowBb6.targetDhiira;
    const bbTargetDhalaa = rowBb4.targetDhalaa + rowBb5.targetDhalaa + rowBb6.targetDhalaa;
    const bbTargetTotal = bbTargetDhiira + bbTargetDhalaa;
    const bbTotal = bbDhiira + bbDhalaa;

    const subBb4to6 = {
      key: 'sub_bb_4_6',
      kutaa: "Subtotal: Ida'ama Bu'uura Boruu (Umurii 4-6)",
      gradeNumber: 0,
      dhiira: bbDhiira,
      dhalaa: bbDhalaa,
      total: bbTotal,
      targetDhiira: bbTargetDhiira,
      targetDhalaa: bbTargetDhalaa,
      targetTotal: bbTargetTotal,
      pctDhiira: bbTargetDhiira > 0 ? parseFloat(((bbDhiira / bbTargetDhiira) * 100).toFixed(1)) : 0,
      pctDhalaa: bbTargetDhalaa > 0 ? parseFloat(((bbDhalaa / bbTargetDhalaa) * 100).toFixed(1)) : 0,
      pctTotal: bbTargetTotal > 0 ? parseFloat(((bbTotal / bbTargetTotal) * 100).toFixed(1)) : 0,
      pct: bbTargetTotal > 0 ? parseFloat(((bbTotal / bbTargetTotal) * 100).toFixed(1)) : 0,
      isSubtotal: true,
      isGrandTotal: false,
    };

    // Grade 1 Students Breakdown
    const g1All = customStudentsList.filter((s) => s.kutaa === '1');
    const g1U7 = g1All.filter((s) => s.umurii === 7);
    const g1U8 = g1All.filter((s) => s.umurii !== 7);

    // Grade 1 Targets Breakdown
    const targetG1All = targets['1'] || { dhiira: 50, dhalaa: 45, kutaa: '1' };
    const targetG1U7 = targets['u7_1'] || { dhiira: 40, dhalaa: 35, kutaa: 'u7_1' };
    const targetG1U8Dhiira = Math.max(0, (targetG1All.dhiira || 0) - (targetG1U7.dhiira || 0));
    const targetG1U8Dhalaa = Math.max(0, (targetG1All.dhalaa || 0) - (targetG1U7.dhalaa || 0));
    const targetG1U8Total = targetG1U8Dhiira + targetG1U8Dhalaa;
    const targetG1AllTotal = (targetG1All.dhiira || 0) + (targetG1All.dhalaa || 0);
    const targetG1U7Total = (targetG1U7.dhiira || 0) + (targetG1U7.dhalaa || 0);

    // 1. Row Umurii 7 (Kutaa 1)
    const g1U7Dhiira = g1U7.filter((s) => s.koorniyaa === 'Dhiira').length;
    const g1U7Dhalaa = g1U7.filter((s) => s.koorniyaa === 'Dhalaa').length;
    const g1U7Total = g1U7Dhiira + g1U7Dhalaa;
    const rowG1_U7 = {
      key: 'u_7_k1',
      kutaa: 'Umurii 7 (Kutaa 1)',
      gradeNumber: 0.7,
      dhiira: g1U7Dhiira,
      dhalaa: g1U7Dhalaa,
      total: g1U7Total,
      targetDhiira: targetG1U7.dhiira || 0,
      targetDhalaa: targetG1U7.dhalaa || 0,
      targetTotal: targetG1U7Total,
      pctDhiira: targetG1U7.dhiira > 0 ? parseFloat(((g1U7Dhiira / targetG1U7.dhiira) * 100).toFixed(1)) : 0,
      pctDhalaa: targetG1U7.dhalaa > 0 ? parseFloat(((g1U7Dhalaa / targetG1U7.dhalaa) * 100).toFixed(1)) : 0,
      pctTotal: targetG1U7Total > 0 ? parseFloat(((g1U7Total / targetG1U7Total) * 100).toFixed(1)) : 0,
      pct: targetG1U7Total > 0 ? parseFloat(((g1U7Total / targetG1U7Total) * 100).toFixed(1)) : 0,
      isSubtotal: false,
      isGrandTotal: false,
    };

    // 2. Row Kutaa 1 (Umurii 8 fi Isaa Ol)
    const g1U8Dhiira = g1U8.filter((s) => s.koorniyaa === 'Dhiira').length;
    const g1U8Dhalaa = g1U8.filter((s) => s.koorniyaa === 'Dhalaa').length;
    const g1U8Total = g1U8Dhiira + g1U8Dhalaa;
    const rowG1_U8 = {
      key: 'u_8_k1',
      kutaa: 'Kutaa 1 (Umurii 8+)',
      gradeNumber: 0.8,
      dhiira: g1U8Dhiira,
      dhalaa: g1U8Dhalaa,
      total: g1U8Total,
      targetDhiira: targetG1U8Dhiira,
      targetDhalaa: targetG1U8Dhalaa,
      targetTotal: targetG1U8Total,
      pctDhiira: targetG1U8Dhiira > 0 ? parseFloat(((g1U8Dhiira / targetG1U8Dhiira) * 100).toFixed(1)) : 0,
      pctDhalaa: targetG1U8Dhalaa > 0 ? parseFloat(((g1U8Dhalaa / targetG1U8Dhalaa) * 100).toFixed(1)) : 0,
      pctTotal: targetG1U8Total > 0 ? parseFloat(((g1U8Total / targetG1U8Total) * 100).toFixed(1)) : 0,
      pct: targetG1U8Total > 0 ? parseFloat(((g1U8Total / targetG1U8Total) * 100).toFixed(1)) : 0,
      isSubtotal: false,
      isGrandTotal: false,
    };

    // 3. Row Waliigalaa Kutaa 1
    const g1AllDhiira = g1All.filter((s) => s.koorniyaa === 'Dhiira').length;
    const g1AllDhalaa = g1All.filter((s) => s.koorniyaa === 'Dhalaa').length;
    const g1AllTotal = g1AllDhiira + g1AllDhalaa;
    const rowG1_Waliigala = {
      key: 'kutaa_1',
      kutaa: 'Waliigalaa Kutaa 1',
      gradeNumber: 1,
      dhiira: g1AllDhiira,
      dhalaa: g1AllDhalaa,
      total: g1AllTotal,
      targetDhiira: targetG1All.dhiira || 0,
      targetDhalaa: targetG1All.dhalaa || 0,
      targetTotal: targetG1AllTotal,
      pctDhiira: targetG1All.dhiira > 0 ? parseFloat(((g1AllDhiira / targetG1All.dhiira) * 100).toFixed(1)) : 0,
      pctDhalaa: targetG1All.dhalaa > 0 ? parseFloat(((g1AllDhalaa / targetG1All.dhalaa) * 100).toFixed(1)) : 0,
      pctTotal: targetG1AllTotal > 0 ? parseFloat(((g1AllTotal / targetG1AllTotal) * 100).toFixed(1)) : 0,
      pct: targetG1AllTotal > 0 ? parseFloat(((g1AllTotal / targetG1AllTotal) * 100).toFixed(1)) : 0,
      isSubtotal: false,
      isGrandTotal: false,
    };

    const baseStats = [
      rowG1_Waliigala,
      ...Array.from({ length: 11 }, (_, i) => {
        const gStr = String(i + 2);
        const inGrade = customStudentsList.filter((s) => s.kutaa === gStr);
        const dhiira = inGrade.filter((s) => s.koorniyaa === 'Dhiira').length;
        const dhalaa = inGrade.filter((s) => s.koorniyaa === 'Dhalaa').length;
        const target = targets[gStr] || { dhiira: 0, dhalaa: 0, kutaa: gStr };
        const targetTotal = target.dhiira + target.dhalaa;
        const totalActual = dhiira + dhalaa;
        const pctDhiira = target.dhiira > 0 ? ((dhiira / target.dhiira) * 100).toFixed(1) : '0.0';
        const pctDhalaa = target.dhalaa > 0 ? ((dhalaa / target.dhalaa) * 100).toFixed(1) : '0.0';
        const pctTotal = targetTotal > 0 ? ((totalActual / targetTotal) * 100).toFixed(1) : '0.0';

        return {
          key: `kutaa_${gStr}`,
          kutaa: `Kutaa ${gStr}`,
          gradeNumber: i + 2,
          dhiira,
          dhalaa,
          total: totalActual,
          targetDhiira: target.dhiira,
          targetDhalaa: target.dhalaa,
          targetTotal,
          pctDhiira: parseFloat(pctDhiira),
          pctDhalaa: parseFloat(pctDhalaa),
          pctTotal: parseFloat(pctTotal),
          pct: parseFloat(pctTotal),
          isSubtotal: false,
          isGrandTotal: false,
        };
      }),
    ];

    const createSubtotalRow = (
      sourceRows: typeof baseStats,
      label: string,
      key: string,
      isGrand = false
    ) => {
      const targetDhiira = sourceRows.reduce((acc, r) => acc + r.targetDhiira, 0);
      const targetDhalaa = sourceRows.reduce((acc, r) => acc + r.targetDhalaa, 0);
      const targetTotal = targetDhiira + targetDhalaa;

      const dhiira = sourceRows.reduce((acc, r) => acc + r.dhiira, 0);
      const dhalaa = sourceRows.reduce((acc, r) => acc + r.dhalaa, 0);
      const total = dhiira + dhalaa;

      const pctDhiira = targetDhiira > 0 ? parseFloat(((dhiira / targetDhiira) * 100).toFixed(1)) : 0;
      const pctDhalaa = targetDhalaa > 0 ? parseFloat(((dhalaa / targetDhalaa) * 100).toFixed(1)) : 0;
      const pctTotal = targetTotal > 0 ? parseFloat(((total / targetTotal) * 100).toFixed(1)) : 0;

      return {
        key,
        kutaa: label,
        gradeNumber: 0,
        dhiira,
        dhalaa,
        total,
        targetDhiira,
        targetDhalaa,
        targetTotal,
        pctDhiira,
        pctDhalaa,
        pctTotal,
        pct: pctTotal,
        isSubtotal: !isGrand,
        isGrandTotal: isGrand,
      };
    };

    const g1to6 = baseStats.slice(0, 6);
    const g7to8 = baseStats.slice(6, 8);
    const g1to8 = baseStats.slice(0, 8);
    const g9to12 = baseStats.slice(8, 12);
    const g1to12 = baseStats.slice(0, 12);

    const sub1to6 = createSubtotalRow(g1to6, "Ida'ama Kutaa 1-6", "sub_1_6");
    const sub7to8 = createSubtotalRow(g7to8, "Ida'ama Kutaa 7-8", "sub_7_8");
    const sub1to8 = createSubtotalRow(g1to8, "Ida'ama Kutaa 1-8", "sub_1_8");
    const sub9to12 = createSubtotalRow(g9to12, "Ida'ama Kutaa 9-12", "sub_9_12");
    const grandTotal = createSubtotalRow(g1to12, "Ida'ama Waliigalaa (Kutaa 1-12)", "grand_1_12", true);

    return [
      rowBb4,
      rowBb5,
      rowBb6,
      subBb4to6,
      rowG1_U7,
      rowG1_U8,
      rowG1_Waliigala,
      ...baseStats.slice(1, 6),
      sub1to6,
      ...baseStats.slice(6, 8),
      sub7to8,
      sub1to8,
      ...baseStats.slice(8, 12),
      sub9to12,
      grandTotal,
    ];
  };

  const structuredGradeStats = getStructuredGradeStats();

  // Export CSV functions for specific tabs
  const exportCurrentTabCSV = () => {
    let exportData: any[] = [];
    const cleanSchoolName = (settings.savedSchoolName || 'Mana_Barumsaa').replace(/\s+/g, '_');
    const cleanYear = (settings.baraBarnootaa || '2019').replace(/\s+/g, '_');
    let filename = `Gabaasa_${activeTab}_${cleanSchoolName}_Bara_${cleanYear}.csv`;

    if (activeTab === 'tabA_karoora') {
      exportData = structuredGradeStats.map((s) => ({
        Kutaa: s.kutaa,
        'Karoora Dhiira': s.targetDhiira,
        'Karoora Dhalaa': s.targetDhalaa,
        'Karoora Waliigala': s.targetTotal,
      }));
    } else if (activeTab === 'tabB_waligalaa') {
      exportData = schoolStudents.map((s, idx) => ({
        '#': idx + 1,
        'STUI Barataa': s.nationalId || s.id || '-',
        'Maqaa Guutuu Barataa': s.maqaaGuutuu,
        'Lakkoofsa waraqaa eenyummaa Dijitaalaa (FAN)': s.fanId,
        Koorniyaa: s.koorniyaa,
        Kutaa: s.kutaa,
        Daree: s.daree,
        'Bara Dhalootaa': s.baraDhalootaa,
        Umurii: s.umurii,
        'Haala Galmee': s.haalaGalmee,
        'Bara Irra Deebii': s.baraIrraDeebii || '-',
        'Bara Addaan Kute': s.baraAddaanKute || '-',
        'Haala Maatii': s.haalaMaatii,
        'Miidhama Qaamaa': s.miidhamaQaamaa,
        'Gosa Miidhamaa': s.gosaMiidhamaa || '-',
        Godina: s.godina,
        Aanaa: s.aanaa,
        Ganda: s.ganda,
        'Bilbila Barataa': s.lakkBilbilaBarataa || '-',
        'Bilbila Maatii': s.lakkBilbilaMaatii || '-',
        'Maqaa Haadhaa': s.maqaaHaadhaa || '-',
        'M/B Duraan': s.mbDuraan,
        Qabxii: s.avireejjiiQabxii,
        'Guyyaa Galmee': s.guyyaaGalmee,
        'Barsiisaa Galmeessee': s.barsiisaaGalmeessee || '-',
      }));
    } else if (activeTab === 'tabC_guyyaa') {
      const todayList = schoolStudents.filter((s) => s.guyyaaGalmee === todayStr || s.guyyaaGalmee === todayFormatted);
      const stats = getStructuredGradeStats(todayList);
      exportData = stats.map((s) => ({
        Kutaa: s.kutaa,
        Dhiira: s.dhiira,
        Dhalaa: s.dhalaa,
        "Ida'ama": s.total,
      }));
    } else if (activeTab === 'tabD_galmee_dheeraa') {
      exportData = structuredGradeStats.map((s) => ({
        Kutaa: s.kutaa,
        Dhiira: s.dhiira,
        Dhalaa: s.dhalaa,
        "Ida'ama": s.total,
      }));
    } else if (activeTab === 'tabE_miidhama_roster') {
      const list = schoolStudents.filter((s) => s.miidhamaQaamaa === 'Eeyyee');
      exportData = list.map((s, idx) => ({
        '#': idx + 1,
        'STUI Barataa': s.nationalId || s.id || '-',
        'Maqaa Guutuu Barataa': s.maqaaGuutuu,
        'Lakkoofsa waraqaa eenyummaa Dijitaalaa (FAN)': s.fanId,
        Kutaa: s.kutaa,
        Koorniyaa: s.koorniyaa,
        'Gosa Miidhamaa': s.gosaMiidhamaa || 'Unspecified',
        Ganda: s.ganda,
      }));
    } else if (activeTab === 'tabF_miidhama_summary') {
      const list = schoolStudents.filter((s) => s.miidhamaQaamaa === 'Eeyyee');
      const stats = getStructuredGradeStats(list);
      exportData = stats.map((s) => ({
        Kutaa: s.kutaa,
        Dhiira: s.dhiira,
        Dhalaa: s.dhalaa,
        "Ida'ama": s.total,
      }));
    } else if (activeTab === 'tabG_irra_deebii_roster') {
      const list = schoolStudents.filter((s) => s.haalaGalmee.toLowerCase().includes('irra deebii'));
      exportData = list.map((s, idx) => ({
        '#': idx + 1,
        'STUI Barataa': s.nationalId || s.id || '-',
        'Maqaa Guutuu Barataa': s.maqaaGuutuu,
        'Lakkoofsa waraqaa eenyummaa Dijitaalaa (FAN)': s.fanId,
        Kutaa: s.kutaa,
        Koorniyaa: s.koorniyaa,
        'Haala Galmee': s.haalaGalmee,
        'Bara Irra Deebii': s.baraIrraDeebii || '-',
      }));
    } else if (activeTab === 'tabH_irra_deebii_summary') {
      const list = schoolStudents.filter((s) => s.haalaGalmee.toLowerCase().includes('irra deebii'));
      const stats = getStructuredGradeStats(list);
      exportData = stats.map((s) => ({
        Kutaa: s.kutaa,
        Dhiira: s.dhiira,
        Dhalaa: s.dhalaa,
        "Ida'ama": s.total,
      }));
    } else if (activeTab === 'tabI_karoora_raawwii') {
      exportData = structuredGradeStats.map((s) => ({
        Kutaa: s.kutaa,
        'Karoora Dhiira': s.targetDhiira,
        'Karoora Dhalaa': s.targetDhalaa,
        'Karoora Total': s.targetTotal,
        'Raawwii Dhiira': s.dhiira,
        'Raawwii Dhalaa': s.dhalaa,
        'Raawwii Total': s.total,
        'Dhiira (%)': `${s.pctDhiira}%`,
        'Dhalaa (%)': `${s.pctDhalaa}%`,
        "Ida'ama (%)": `${s.pctTotal}%`,
      }));
    }

    exportToCSV(filename, exportData);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Controls Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4 print:hidden">
        <div>
          <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
            <FileText className="w-6 h-6 text-indigo-600" />
            <span>Kutaa Gabaasa Sub-tabs 9 (Tab A - Tab I)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Mana Barumsaa: <strong className="text-indigo-600">{settings.savedSchoolName}</strong> | Bara Barnootaa: <strong className="text-indigo-600">{settings.baraBarnootaa} E.C</strong>
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition flex items-center gap-2 text-xs cursor-pointer border border-slate-300"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>

          <button
            onClick={exportCurrentTabCSV}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition flex items-center gap-2 text-xs cursor-pointer shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Export Excel / CSV</span>
          </button>
        </div>
      </div>

      {/* Sub-Tabs Navigation (Tab A to Tab I) */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-sm print:hidden overflow-x-auto">
        <div className="flex gap-1 min-w-[900px]">
          
          <button
            onClick={() => setActiveTab('tabA_karoora')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'tabA_karoora' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Target className="w-4 h-4" />
            <span>Tab A: Karoora Galchu</span>
          </button>

          <button
            onClick={() => setActiveTab('tabB_waligalaa')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'tabB_waligalaa' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Table className="w-4 h-4" />
            <span>Tab B: Gabaasa Waliigalaa</span>
          </button>

          <button
            onClick={() => setActiveTab('tabC_guyyaa')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'tabC_guyyaa' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Tab C: Gabaasa Guyyaa</span>
          </button>

          <button
            onClick={() => setActiveTab('tabD_galmee_dheeraa')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'tabD_galmee_dheeraa' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Tab D: Galmee Dheeraa</span>
          </button>

          <button
            onClick={() => setActiveTab('tabE_miidhama_roster')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'tabE_miidhama_roster' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <HeartHandshake className="w-4 h-4" />
            <span>Tab E: Miidhama Roster</span>
          </button>

          <button
            onClick={() => setActiveTab('tabF_miidhama_summary')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'tabF_miidhama_summary' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Tab F: Miidhama Summary</span>
          </button>

          <button
            onClick={() => setActiveTab('tabG_irra_deebii_roster')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'tabG_irra_deebii_roster' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span>Tab G: Irra Deebii Roster</span>
          </button>

          <button
            onClick={() => setActiveTab('tabH_irra_deebii_summary')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'tabH_irra_deebii_summary' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <PieChart className="w-4 h-4" />
            <span>Tab H: Irra Deebii Summary</span>
          </button>

          <button
            onClick={() => setActiveTab('tabI_karoora_raawwii')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'tabI_karoora_raawwii' ? 'bg-emerald-600 text-white shadow-md' : 'text-emerald-800 bg-emerald-50 hover:bg-emerald-100'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Tab I: Karoora vs Raawwii %</span>
          </button>

        </div>
      </div>

      {/* Report Global Filters (Umurii 7 & Alphabet Sort) */}
      <div className="bg-gradient-to-r from-slate-50 via-indigo-50/50 to-slate-50 p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3 print:hidden">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-indigo-600 shrink-0" />
          <span className="text-xs font-black text-slate-800">Callyin Gabaasaa (Report Filters):</span>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Umurii Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-600">Umurii:</span>
            <select
              value={reportAgeFilter}
              onChange={(e) => setReportAgeFilter(e.target.value as any)}
              className={`py-1.5 px-3 rounded-xl text-xs font-extrabold focus:outline-none focus:ring-2 focus:ring-indigo-500 border cursor-pointer transition ${
                reportAgeFilter === '7'
                  ? 'bg-amber-400 text-slate-950 border-amber-500 shadow-sm'
                  : 'bg-white border-slate-300 text-slate-800'
              }`}
            >
              <option value="ALL">Umurii Hundaa (All Ages)</option>
              <option value="7">⚡ Umurii 7 Qofa (Age 7 Only)</option>
              <option value="4_6">Bu'uura Boruu (Umurii 4-6)</option>
              <option value="8_plus">Umurii 8 fi Isaa Ol</option>
            </select>
          </div>

          {/* Sort Order */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-600">Tartiiba:</span>
            <select
              value={reportSortOrder}
              onChange={(e) => setReportSortOrder(e.target.value as any)}
              className="py-1.5 px-3 bg-white border border-slate-300 text-slate-800 font-bold rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
            >
              <option value="AZ">🔤 Alphabet (A - Z)</option>
              <option value="ZA">🔤 Alphabet (Z - A)</option>
              <option value="DEFAULT">📋 Default</option>
            </select>
          </div>

          {/* Quick Filter Badge */}
          {reportAgeFilter === '7' && (
            <span className="px-2.5 py-1 bg-amber-100 text-amber-900 border border-amber-300 rounded-lg text-[11px] font-extrabold animate-pulse flex items-center gap-1">
              ✓ Barattoota Umurii 7 Qofa Agarsiisaa Jira! ({schoolStudents.length})
            </span>
          )}
        </div>
      </div>

      {/* Printable Official Header */}
      <div className="hidden print:block text-center border-b-2 border-slate-900 pb-4 mb-6">
        <h1 className="text-xl font-black uppercase text-slate-900">
          Gabaasa Manneen Barnootaa / School Education Report
        </h1>
        <h2 className="text-md font-bold text-slate-800">
          {settings.savedSchoolName} — Bara Barnootaa {settings.baraBarnootaa} E.C
        </h2>
        <p className="text-xs text-slate-600 font-mono mt-1">
          Guyyaa Gabaasaa: {new Date().toLocaleDateString('en-GB')}
        </p>
      </div>

      {/* TAB A: Karoora Galchuu */}
      {activeTab === 'tabA_karoora' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Target className="w-5 h-5 text-indigo-600" />
                <span>Tab A: Kutaa Karoora Galchuu (Grade Target Configuration)</span>
              </h3>
              <p className="text-xs text-slate-500">
                Karoora barattoota dhiiraa fi dhalaa kutaa 1-12 guutaa save godhaa. Ida'amni marsaa (1-6, 7-8, 1-8, 9-12, 1-12) ofumaan herregama.
              </p>
            </div>
          </div>

          {targetSuccessMsg && (
            <div className="p-3 bg-emerald-100 border border-emerald-300 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>Karoorri barattootaa milkaa'inaan save ta'eera! (Targets updated successfully)</span>
            </div>
          )}

          <form onSubmit={handleSaveTargetsSubmit} className="space-y-6">
            {/* Section 1: Kutaa 1 - 6 */}
            <div className="space-y-3 p-4 bg-slate-50/70 border border-slate-200 rounded-2xl">
              <h4 className="font-extrabold text-sm text-indigo-900 border-b border-slate-200 pb-2 flex items-center justify-between">
                <span>1. Kutaa 1 - 6 (Primary Lower)</span>
                <span className="text-xs font-semibold text-slate-500">Kutaa 1 hanga 6</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                {['1', '2', '3', '4', '5', '6'].map((g) => {
                  const target = editingTargets[g] || { dhiira: 0, dhalaa: 0 };
                  return (
                    <div key={g} className="p-3 bg-white border border-slate-200 rounded-xl space-y-2 shadow-xs">
                      <h5 className="font-extrabold text-xs text-indigo-900">Kutaa {g}</h5>
                      <div className="grid grid-cols-2 gap-1.5 text-xs">
                        <div>
                          <label className="block text-[10px] text-slate-600 font-semibold mb-0.5">Dhiira</label>
                          <input
                            type="number"
                            min="0"
                            value={target.dhiira}
                            onChange={(e) => handleTargetChange(g, 'dhiira', parseInt(e.target.value) || 0)}
                            className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-sky-800 text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-600 font-semibold mb-0.5">Dhalaa</label>
                          <input
                            type="number"
                            min="0"
                            value={target.dhalaa}
                            onChange={(e) => handleTargetChange(g, 'dhalaa', parseInt(e.target.value) || 0)}
                            className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-rose-800 text-xs"
                          />
                        </div>
                      </div>
                      <div className="text-[10px] font-bold text-slate-600 pt-1 border-t border-slate-100 flex justify-between">
                        <span>Ida'ama:</span>
                        <span className="text-indigo-700 font-mono">{target.dhiira + target.dhalaa}</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Subtotal Banner 1-6 */}
              {(() => {
                const sub1_6 = ['1', '2', '3', '4', '5', '6'].reduce(
                  (acc, g) => {
                    const t = editingTargets[g] || { dhiira: 0, dhalaa: 0 };
                    return { dhiira: acc.dhiira + t.dhiira, dhalaa: acc.dhalaa + t.dhalaa };
                  },
                  { dhiira: 0, dhalaa: 0 }
                );
                return (
                  <div className="p-3 bg-indigo-100/80 border border-indigo-300 rounded-xl text-xs flex flex-wrap items-center justify-between font-bold text-indigo-950">
                    <span className="uppercase tracking-wider">Ida'ama Karooraa Kutaa 1-6:</span>
                    <div className="flex gap-4">
                      <span>Dhiira: <strong className="text-sky-800">{sub1_6.dhiira}</strong></span>
                      <span>Dhalaa: <strong className="text-rose-800">{sub1_6.dhalaa}</strong></span>
                      <span>Ida'ama: <strong className="text-indigo-900 font-black">{sub1_6.dhiira + sub1_6.dhalaa}</strong></span>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Section 2: Kutaa 7 - 8 */}
            <div className="space-y-3 p-4 bg-slate-50/70 border border-slate-200 rounded-2xl">
              <h4 className="font-extrabold text-sm text-indigo-900 border-b border-slate-200 pb-2 flex items-center justify-between">
                <span>2. Kutaa 7 - 8 (Primary Upper)</span>
                <span className="text-xs font-semibold text-slate-500">Kutaa 7 fi 8</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md">
                {['7', '8'].map((g) => {
                  const target = editingTargets[g] || { dhiira: 0, dhalaa: 0 };
                  return (
                    <div key={g} className="p-3 bg-white border border-slate-200 rounded-xl space-y-2 shadow-xs">
                      <h5 className="font-extrabold text-xs text-indigo-900">Kutaa {g}</h5>
                      <div className="grid grid-cols-2 gap-1.5 text-xs">
                        <div>
                          <label className="block text-[10px] text-slate-600 font-semibold mb-0.5">Dhiira</label>
                          <input
                            type="number"
                            min="0"
                            value={target.dhiira}
                            onChange={(e) => handleTargetChange(g, 'dhiira', parseInt(e.target.value) || 0)}
                            className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-sky-800 text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-600 font-semibold mb-0.5">Dhalaa</label>
                          <input
                            type="number"
                            min="0"
                            value={target.dhalaa}
                            onChange={(e) => handleTargetChange(g, 'dhalaa', parseInt(e.target.value) || 0)}
                            className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-rose-800 text-xs"
                          />
                        </div>
                      </div>
                      <div className="text-[10px] font-bold text-slate-600 pt-1 border-t border-slate-100 flex justify-between">
                        <span>Ida'ama:</span>
                        <span className="text-indigo-700 font-mono">{target.dhiira + target.dhalaa}</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Subtotal Banners 7-8 and 1-8 */}
              {(() => {
                const sub7_8 = ['7', '8'].reduce(
                  (acc, g) => {
                    const t = editingTargets[g] || { dhiira: 0, dhalaa: 0 };
                    return { dhiira: acc.dhiira + t.dhiira, dhalaa: acc.dhalaa + t.dhalaa };
                  },
                  { dhiira: 0, dhalaa: 0 }
                );
                const sub1_8 = ['1', '2', '3', '4', '5', '6', '7', '8'].reduce(
                  (acc, g) => {
                    const t = editingTargets[g] || { dhiira: 0, dhalaa: 0 };
                    return { dhiira: acc.dhiira + t.dhiira, dhalaa: acc.dhalaa + t.dhalaa };
                  },
                  { dhiira: 0, dhalaa: 0 }
                );
                return (
                  <div className="space-y-2">
                    <div className="p-3 bg-indigo-100/80 border border-indigo-300 rounded-xl text-xs flex flex-wrap items-center justify-between font-bold text-indigo-950">
                      <span className="uppercase tracking-wider">Ida'ama Karooraa Kutaa 7-8:</span>
                      <div className="flex gap-4">
                        <span>Dhiira: <strong className="text-sky-800">{sub7_8.dhiira}</strong></span>
                        <span>Dhalaa: <strong className="text-rose-800">{sub7_8.dhalaa}</strong></span>
                        <span>Ida'ama: <strong className="text-indigo-900 font-black">{sub7_8.dhiira + sub7_8.dhalaa}</strong></span>
                      </div>
                    </div>
                    <div className="p-3 bg-purple-100/80 border border-purple-300 rounded-xl text-xs flex flex-wrap items-center justify-between font-bold text-purple-950">
                      <span className="uppercase tracking-wider">Ida'ama Karooraa Kutaa 1-8 (Primary Total):</span>
                      <div className="flex gap-4">
                        <span>Dhiira: <strong className="text-sky-800">{sub1_8.dhiira}</strong></span>
                        <span>Dhalaa: <strong className="text-rose-800">{sub1_8.dhalaa}</strong></span>
                        <span>Ida'ama: <strong className="text-purple-900 font-black">{sub1_8.dhiira + sub1_8.dhalaa}</strong></span>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Section 3: Kutaa 9 - 12 */}
            <div className="space-y-3 p-4 bg-slate-50/70 border border-slate-200 rounded-2xl">
              <h4 className="font-extrabold text-sm text-indigo-900 border-b border-slate-200 pb-2 flex items-center justify-between">
                <span>3. Kutaa 9 - 12 (Secondary)</span>
                <span className="text-xs font-semibold text-slate-500">Kutaa 9 hanga 12</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                {['9', '10', '11', '12'].map((g) => {
                  const target = editingTargets[g] || { dhiira: 0, dhalaa: 0 };
                  return (
                    <div key={g} className="p-3 bg-white border border-slate-200 rounded-xl space-y-2 shadow-xs">
                      <h5 className="font-extrabold text-xs text-indigo-900">Kutaa {g}</h5>
                      <div className="grid grid-cols-2 gap-1.5 text-xs">
                        <div>
                          <label className="block text-[10px] text-slate-600 font-semibold mb-0.5">Dhiira</label>
                          <input
                            type="number"
                            min="0"
                            value={target.dhiira}
                            onChange={(e) => handleTargetChange(g, 'dhiira', parseInt(e.target.value) || 0)}
                            className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-sky-800 text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-600 font-semibold mb-0.5">Dhalaa</label>
                          <input
                            type="number"
                            min="0"
                            value={target.dhalaa}
                            onChange={(e) => handleTargetChange(g, 'dhalaa', parseInt(e.target.value) || 0)}
                            className="w-full p-1.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-rose-800 text-xs"
                          />
                        </div>
                      </div>
                      <div className="text-[10px] font-bold text-slate-600 pt-1 border-t border-slate-100 flex justify-between">
                        <span>Ida'ama:</span>
                        <span className="text-indigo-700 font-mono">{target.dhiira + target.dhalaa}</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Subtotal Banners 9-12 and 1-12 */}
              {(() => {
                const sub9_12 = ['9', '10', '11', '12'].reduce(
                  (acc, g) => {
                    const t = editingTargets[g] || { dhiira: 0, dhalaa: 0 };
                    return { dhiira: acc.dhiira + t.dhiira, dhalaa: acc.dhalaa + t.dhalaa };
                  },
                  { dhiira: 0, dhalaa: 0 }
                );
                const sub1_12 = Array.from({ length: 12 }, (_, i) => String(i + 1)).reduce(
                  (acc, g) => {
                    const t = editingTargets[g] || { dhiira: 0, dhalaa: 0 };
                    return { dhiira: acc.dhiira + t.dhiira, dhalaa: acc.dhalaa + t.dhalaa };
                  },
                  { dhiira: 0, dhalaa: 0 }
                );
                return (
                  <div className="space-y-2">
                    <div className="p-3 bg-indigo-100/80 border border-indigo-300 rounded-xl text-xs flex flex-wrap items-center justify-between font-bold text-indigo-950">
                      <span className="uppercase tracking-wider">Ida'ama Karooraa Kutaa 9-12:</span>
                      <div className="flex gap-4">
                        <span>Dhiira: <strong className="text-sky-800">{sub9_12.dhiira}</strong></span>
                        <span>Dhalaa: <strong className="text-rose-800">{sub9_12.dhalaa}</strong></span>
                        <span>Ida'ama: <strong className="text-indigo-900 font-black">{sub9_12.dhiira + sub9_12.dhalaa}</strong></span>
                      </div>
                    </div>
                    <div className="p-4 bg-slate-900 text-white rounded-xl text-xs flex flex-wrap items-center justify-between font-bold border-2 border-amber-400">
                      <span className="uppercase tracking-wider text-amber-300 font-black">Ida'ama Waliigalaa Karooraa (Kutaa 1-12):</span>
                      <div className="flex gap-6 text-sm">
                        <span>Dhiira: <strong className="text-sky-300">{sub1_12.dhiira}</strong></span>
                        <span>Dhalaa: <strong className="text-rose-300">{sub1_12.dhalaa}</strong></span>
                        <span>Ida'ama: <strong className="text-amber-300 font-black">{sub1_12.dhiira + sub1_12.dhalaa}</strong></span>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            <div className="text-right pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md text-xs cursor-pointer"
              >
                Karoora Ol-ka'i (Save All Targets)
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB B: Gabaasa Waliigalaa Barataa (Master Grid) */}
      {activeTab === 'tabB_waligalaa' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Table className="w-5 h-5 text-indigo-600" />
                <span>Tab B: Gabaasa Waligalaa Barataa Galmaa'e (Full Registration Grid)</span>
              </h3>
              <p className="text-xs text-slate-500">
                Ulaagalee galmee sana hunda qabu excell, print fi download godhaa.
              </p>
            </div>
            <div className="relative w-full md:w-64">
              <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Barbaadi..."
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
              />
            </div>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs text-slate-700 border-collapse">
              <thead className="bg-slate-100 text-slate-900 uppercase font-bold text-[11px] border-b border-slate-300">
                <tr>
                  <th className="px-2.5 py-3 border-r whitespace-nowrap text-center">#</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap text-center">Lakk. STUI Barataa (STU ID)</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Maqaa Guutuu Barataa</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap text-center">Lakkoofsa waraqaa eenyummaa Dijitaalaa (FAN)</th>
                  <th className="px-2.5 py-3 border-r whitespace-nowrap text-center">Koorniyaa</th>
                  <th className="px-2.5 py-3 border-r whitespace-nowrap text-center">Kutaa</th>
                  <th className="px-2.5 py-3 border-r whitespace-nowrap text-center">Daree</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Bara Dhalootaa</th>
                  <th className="px-2.5 py-3 border-r whitespace-nowrap text-center">Umurii</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Haala Galmee</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Miidhama Qaamaa</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Gosa Miidhamaa</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Godina</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Aanaa</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Ganda</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Bilbila Barataa</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Bilbila Maatii</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Maqaa Haadhaa</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">M/B Duraan</th>
                  <th className="px-2.5 py-3 border-r whitespace-nowrap text-center">Qabxii (%)</th>
                  <th className="px-3 py-3 border-r whitespace-nowrap">Guyyaa Galmee</th>
                  <th className="px-3 py-3 whitespace-nowrap">Barsiisaa Galmeessee</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {schoolStudents
                  .filter(
                    (s) =>
                      s.maqaaGuutuu.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      s.ganda.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      s.fanId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      (s.nationalId && s.nationalId.toLowerCase().includes(searchTerm.toLowerCase())) ||
                      s.godina.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      s.aanaa.toLowerCase().includes(searchTerm.toLowerCase())
                  )
                  .map((s, idx) => (
                    <tr key={s.id} className="hover:bg-slate-50 font-medium border-b border-slate-100">
                      <td className="px-2.5 py-2 border-r text-slate-400 font-mono text-[11px] text-center">{idx + 1}</td>
                      <td className="px-3 py-2 border-r font-mono text-indigo-700 font-bold whitespace-nowrap text-center">
                        {s.nationalId || s.id || '-'}
                      </td>
                      <td className="px-3 py-2 border-r font-bold text-slate-900 whitespace-nowrap">{s.maqaaGuutuu}</td>
                      <td className="px-3 py-2 border-r font-mono text-slate-700 font-bold whitespace-nowrap text-center">{s.fanId}</td>
                      <td className="px-2.5 py-2 border-r whitespace-nowrap text-center">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${s.koorniyaa === 'Dhiira' ? 'bg-sky-100 text-sky-800' : 'bg-rose-100 text-rose-800'}`}>
                          {s.koorniyaa}
                        </span>
                      </td>
                      <td className="px-2.5 py-2 border-r font-bold whitespace-nowrap text-center">Kutaa {s.kutaa}</td>
                      <td className="px-2.5 py-2 border-r text-center font-bold whitespace-nowrap">{s.daree}</td>
                      <td className="px-3 py-2 border-r font-mono whitespace-nowrap text-slate-800">{s.baraDhalootaa}</td>
                      <td className="px-2.5 py-2 border-r text-center font-bold whitespace-nowrap">{s.umurii}</td>
                      <td className="px-3 py-2 border-r text-amber-900 font-bold whitespace-nowrap">{s.haalaGalmee}</td>
                      <td className="px-3 py-2 border-r whitespace-nowrap">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${s.miidhamaQaamaa === 'Eeyyee' ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-slate-100 text-slate-600'}`}>
                          {s.miidhamaQaamaa}
                        </span>
                      </td>
                      <td className="px-3 py-2 border-r text-slate-700 whitespace-nowrap">{s.miidhamaQaamaa === 'Eeyyee' ? s.gosaMiidhamaa || '-' : '-'}</td>
                      <td className="px-3 py-2 border-r text-slate-700 whitespace-nowrap">{s.godina || '-'}</td>
                      <td className="px-3 py-2 border-r text-slate-700 whitespace-nowrap">{s.aanaa || '-'}</td>
                      <td className="px-3 py-2 border-r text-slate-700 whitespace-nowrap">{s.ganda || '-'}</td>
                      <td className="px-3 py-2 border-r font-mono text-slate-700 whitespace-nowrap">{s.lakkBilbilaBarataa || '-'}</td>
                      <td className="px-3 py-2 border-r font-mono text-slate-700 whitespace-nowrap">{s.lakkBilbilaMaatii || '-'}</td>
                      <td className="px-3 py-2 border-r text-slate-700 whitespace-nowrap">{s.maqaaHaadhaa || '-'}</td>
                      <td className="px-3 py-2 border-r text-slate-700 whitespace-nowrap">{s.mbDuraan}</td>
                      <td className="px-2.5 py-2 border-r font-bold text-emerald-800 text-center whitespace-nowrap">{s.avireejjiiQabxii}%</td>
                      <td className="px-3 py-2 border-r text-slate-600 whitespace-nowrap font-mono text-[11px]">{s.guyyaaGalmee}</td>
                      <td className="px-3 py-2 text-slate-700 whitespace-nowrap">{s.barsiisaaGalmeessee || '-'}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB C: Guca Gabaasa Guyyaa Guyyaa */}
      {activeTab === 'tabC_guyyaa' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-indigo-600" />
                <span>Tab C: Guca Gabaasa Guyyaa Guyyaa (Daily Registration Report)</span>
              </h3>
              <p className="text-xs text-slate-500">
                Barattoota guyyaa har'aa galma'an kutaa fi koorniyaan qindeessuu. Ida'ama 1-6, 7-8, 1-8, 9-12 fi 1-12 of keessatti qaba.
              </p>
            </div>
            <div className="px-3 py-1.5 bg-indigo-50 border border-indigo-200 rounded-xl text-xs font-bold text-indigo-900">
              Guyyaa Har'aa: {todayFormatted} ({todayStr})
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse border border-slate-300">
              <thead className="bg-slate-100 text-slate-900 uppercase font-bold text-[11px]">
                <tr>
                  <th className="border border-slate-300 p-2.5">Kutaa / Ida'ama</th>
                  <th className="border border-slate-300 p-2.5 text-center">Dhiira (Today)</th>
                  <th className="border border-slate-300 p-2.5 text-center">Dhalaa (Today)</th>
                  <th className="border border-slate-300 p-2.5 text-center bg-indigo-50 text-indigo-900">Ida'ama Guyyaa</th>
                </tr>
              </thead>
              <tbody>
                {getStructuredGradeStats(schoolStudents.filter((s) => s.guyyaaGalmee === todayStr || s.guyyaaGalmee === todayFormatted)).map((st) => (
                  <tr
                    key={st.key}
                    className={
                      st.isGrandTotal
                        ? 'bg-slate-900 text-white font-black'
                        : st.isSubtotal
                        ? 'bg-indigo-100/90 text-indigo-950 font-extrabold border-t-2 border-b-2 border-indigo-300'
                        : 'hover:bg-slate-50 font-medium'
                    }
                  >
                    <td className={`border border-slate-300 p-2 font-bold ${st.isGrandTotal ? 'text-amber-300' : st.isSubtotal ? 'text-indigo-950 font-black' : 'text-slate-900'}`}>
                      {st.kutaa}
                    </td>
                    <td className="border border-slate-300 p-2 text-center text-sky-700 font-bold">{st.dhiira}</td>
                    <td className="border border-slate-300 p-2 text-center text-rose-700 font-bold">{st.dhalaa}</td>
                    <td className={`border border-slate-300 p-2 text-center font-black ${st.isGrandTotal ? 'bg-amber-400 text-slate-900' : st.isSubtotal ? 'bg-indigo-200/60 text-indigo-950' : 'bg-indigo-50/50 text-indigo-900'}`}>
                      {st.total}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB D: Gabaasa Galmee Waligalaa */}
      {activeTab === 'tabD_galmee_dheeraa' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="pb-3 border-b border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-600" />
              <span>Tab D: Gabaasa Galmee Waligalaa (Overall Progress Report)</span>
            </h3>
            <p className="text-xs text-slate-500">
              Hanguma guyyaan dabalaa deemuun galmee qindeessaa deema (1-6, 7-8, 1-8, 9-12, 1-12).
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse border border-slate-300">
              <thead className="bg-slate-100 text-slate-900 uppercase font-bold text-[11px]">
                <tr>
                  <th className="border border-slate-300 p-2.5">Kutaa / Ida'ama</th>
                  <th className="border border-slate-300 p-2.5 text-center">Dhiira</th>
                  <th className="border border-slate-300 p-2.5 text-center">Dhalaa</th>
                  <th className="border border-slate-300 p-2.5 text-center bg-indigo-50 text-indigo-900">Ida'ama Waligalaa</th>
                </tr>
              </thead>
              <tbody>
                {structuredGradeStats.map((st) => (
                  <tr
                    key={st.key}
                    className={
                      st.isGrandTotal
                        ? 'bg-slate-900 text-white font-black'
                        : st.isSubtotal
                        ? 'bg-indigo-100/90 text-indigo-950 font-extrabold border-t-2 border-b-2 border-indigo-300'
                        : 'hover:bg-slate-50 font-medium'
                    }
                  >
                    <td className={`border border-slate-300 p-2 font-bold ${st.isGrandTotal ? 'text-amber-300' : st.isSubtotal ? 'text-indigo-950 font-black' : 'text-slate-900'}`}>
                      {st.kutaa}
                    </td>
                    <td className="border border-slate-300 p-2 text-center text-sky-700 font-bold">{st.dhiira}</td>
                    <td className="border border-slate-300 p-2 text-center text-rose-700 font-bold">{st.dhalaa}</td>
                    <td className={`border border-slate-300 p-2 text-center font-black ${st.isGrandTotal ? 'bg-amber-400 text-slate-900' : st.isSubtotal ? 'bg-indigo-200/60 text-indigo-950' : 'bg-indigo-50/50 text-indigo-900'}`}>
                      {st.total}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB E: Miidhama Qaamaa Roster */}
      {activeTab === 'tabE_miidhama_roster' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="pb-3 border-b border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <HeartHandshake className="w-5 h-5 text-indigo-600" />
              <span>Tab E: Barattoota Miidhama Qaama Qaban (Special Needs Roster)</span>
            </h3>
            <p className="text-xs text-slate-500">
              Maqaa, kutaa, koorniyaa fi gosa miidhama qaamaa isaaniin qindaaye.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200">
              <thead className="bg-slate-100 text-slate-900 uppercase font-bold text-[11px]">
                <tr>
                  <th className="p-3 border text-center">#</th>
                  <th className="p-3 border text-center">Lakk. STUI Barataa (STU ID)</th>
                  <th className="p-3 border">Maqaa Guutuu Barataa</th>
                  <th className="p-3 border text-center">Lakkoofsa waraqaa eenyummaa Dijitaalaa (FAN)</th>
                  <th className="p-3 border text-center">Kutaa</th>
                  <th className="p-3 border text-center">Koorniyaa</th>
                  <th className="p-3 border">Gosa Miidhamaa</th>
                  <th className="p-3 border">Ganda</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {schoolStudents
                  .filter((s) => s.miidhamaQaamaa === 'Eeyyee')
                  .map((s, idx) => (
                    <tr key={s.id} className="hover:bg-slate-50 font-medium">
                      <td className="p-3 border text-slate-400 text-center">{idx + 1}</td>
                      <td className="p-3 border font-mono text-indigo-700 font-bold text-center">{s.nationalId || s.id || '-'}</td>
                      <td className="p-3 border font-bold text-slate-900">{s.maqaaGuutuu}</td>
                      <td className="p-3 border font-mono text-slate-700 font-bold text-center">{s.fanId}</td>
                      <td className="p-3 border text-center">Kutaa {s.kutaa} ({s.daree})</td>
                      <td className="p-3 border text-center">{s.koorniyaa}</td>
                      <td className="p-3 border font-bold text-amber-800 bg-amber-50">{s.gosaMiidhamaa || 'Unspecified'}</td>
                      <td className="p-3 border">{s.ganda}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB F: Lakkoofsa Miidhama Qaamaa Summary */}
      {activeTab === 'tabF_miidhama_summary' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="pb-3 border-b border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-indigo-600" />
              <span>Tab F: Gabaasa Lakkoofsa Miidhama Qaamaa (Special Needs Summary)</span>
            </h3>
            <p className="text-xs text-slate-500">
              Baay'ina barattoota miidhama qaamaa kutaa fi koorniyaan (ida'ama marsaa 1-6, 7-8, 1-8, 9-12, 1-12 wajjin).
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse border border-slate-300">
              <thead className="bg-slate-100 text-slate-900 uppercase font-bold text-[11px]">
                <tr>
                  <th className="border border-slate-300 p-2.5">Kutaa / Ida'ama</th>
                  <th className="border border-slate-300 p-2.5 text-center">Dhiira</th>
                  <th className="border border-slate-300 p-2.5 text-center">Dhalaa</th>
                  <th className="border border-slate-300 p-2.5 text-center bg-indigo-50 text-indigo-900">Ida'ama</th>
                </tr>
              </thead>
              <tbody>
                {getStructuredGradeStats(schoolStudents.filter((s) => s.miidhamaQaamaa === 'Eeyyee')).map((st) => (
                  <tr
                    key={st.key}
                    className={
                      st.isGrandTotal
                        ? 'bg-slate-900 text-white font-black'
                        : st.isSubtotal
                        ? 'bg-indigo-100/90 text-indigo-950 font-extrabold border-t-2 border-b-2 border-indigo-300'
                        : 'hover:bg-slate-50 font-medium'
                    }
                  >
                    <td className={`border border-slate-300 p-2 font-bold ${st.isGrandTotal ? 'text-amber-300' : st.isSubtotal ? 'text-indigo-950 font-black' : 'text-slate-900'}`}>
                      {st.kutaa}
                    </td>
                    <td className="border border-slate-300 p-2 text-center text-sky-700 font-bold">{st.dhiira}</td>
                    <td className="border border-slate-300 p-2 text-center text-rose-700 font-bold">{st.dhalaa}</td>
                    <td className={`border border-slate-300 p-2 text-center font-black ${st.isGrandTotal ? 'bg-amber-400 text-slate-900' : st.isSubtotal ? 'bg-indigo-200/60 text-indigo-950' : 'bg-indigo-50/50 text-indigo-900'}`}>
                      {st.total}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB G: Irra Deebii Roster */}
      {activeTab === 'tabG_irra_deebii_roster' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="pb-3 border-b border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <RotateCcw className="w-5 h-5 text-indigo-600" />
              <span>Tab G: Barattoota Irra Deebi'an Roster (Repeaters List)</span>
            </h3>
            <p className="text-xs text-slate-500">
              Irra deebii (kufe), Irra deebii (kutee), fi M/B biroo walitti makee.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200">
              <thead className="bg-slate-100 text-slate-900 uppercase font-bold text-[11px]">
                <tr>
                  <th className="p-3 border text-center">#</th>
                  <th className="p-3 border text-center">Lakk. STUI Barataa (STU ID)</th>
                  <th className="p-3 border">Maqaa Guutuu Barataa</th>
                  <th className="p-3 border text-center">Lakkoofsa waraqaa eenyummaa Dijitaalaa (FAN)</th>
                  <th className="p-3 border text-center">Kutaa</th>
                  <th className="p-3 border text-center">Koorniyaa</th>
                  <th className="p-3 border">Haala Galmee</th>
                  <th className="p-3 border text-center">Bara Irra Deebii</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {schoolStudents
                  .filter((s) => s.haalaGalmee.toLowerCase().includes('irra deebii'))
                  .map((s, idx) => (
                    <tr key={s.id} className="hover:bg-slate-50 font-medium">
                      <td className="p-3 border text-slate-400 text-center">{idx + 1}</td>
                      <td className="p-3 border font-mono text-indigo-700 font-bold text-center">{s.nationalId || s.id || '-'}</td>
                      <td className="p-3 border font-bold text-slate-900">{s.maqaaGuutuu}</td>
                      <td className="p-3 border font-mono text-slate-700 font-bold text-center">{s.fanId}</td>
                      <td className="p-3 border text-center">Kutaa {s.kutaa}</td>
                      <td className="p-3 border text-center">{s.koorniyaa}</td>
                      <td className="p-3 border font-bold text-rose-700 bg-rose-50">{s.haalaGalmee}</td>
                      <td className="p-3 border font-mono font-bold text-center">{s.baraIrraDeebii || '-'}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB H: Irra Deebii Summary */}
      {activeTab === 'tabH_irra_deebii_summary' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="pb-3 border-b border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <PieChart className="w-5 h-5 text-indigo-600" />
              <span>Tab H: Gabaasa Lakkoofsa Irra Deebii (Repeaters Statistical Summary)</span>
            </h3>
            <p className="text-xs text-slate-500">
              Lakkoofsa barattoota irra deebi'anii kutaa fi koorniyaan (ida'ama marsaa 1-6, 7-8, 1-8, 9-12, 1-12 wajjin).
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse border border-slate-300">
              <thead className="bg-slate-100 text-slate-900 uppercase font-bold text-[11px]">
                <tr>
                  <th className="border border-slate-300 p-2.5">Kutaa / Ida'ama</th>
                  <th className="border border-slate-300 p-2.5 text-center">Dhiira</th>
                  <th className="border border-slate-300 p-2.5 text-center">Dhalaa</th>
                  <th className="border border-slate-300 p-2.5 text-center bg-indigo-50 text-indigo-900">Ida'ama</th>
                </tr>
              </thead>
              <tbody>
                {getStructuredGradeStats(schoolStudents.filter((s) => s.haalaGalmee.toLowerCase().includes('irra deebii'))).map((st) => (
                  <tr
                    key={st.key}
                    className={
                      st.isGrandTotal
                        ? 'bg-slate-900 text-white font-black'
                        : st.isSubtotal
                        ? 'bg-indigo-100/90 text-indigo-950 font-extrabold border-t-2 border-b-2 border-indigo-300'
                        : 'hover:bg-slate-50 font-medium'
                    }
                  >
                    <td className={`border border-slate-300 p-2 font-bold ${st.isGrandTotal ? 'text-amber-300' : st.isSubtotal ? 'text-indigo-950 font-black' : 'text-slate-900'}`}>
                      {st.kutaa}
                    </td>
                    <td className="border border-slate-300 p-2 text-center text-sky-700 font-bold">{st.dhiira}</td>
                    <td className="border border-slate-300 p-2 text-center text-rose-700 font-bold">{st.dhalaa}</td>
                    <td className={`border border-slate-300 p-2 text-center font-black ${st.isGrandTotal ? 'bg-amber-400 text-slate-900' : st.isSubtotal ? 'bg-indigo-200/60 text-indigo-950' : 'bg-indigo-50/50 text-indigo-900'}`}>
                      {st.total}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB I: Karoora vs Raawwii % (Primary Woreda Office Report) */}
      {activeTab === 'tabI_karoora_raawwii' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="pb-3 border-b border-slate-200">
            <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <Award className="w-6 h-6 text-emerald-600" />
              <span>Tab I: Gabaasa Qulqulluu Karoora vs Raawwii & % (Master Education Report)</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Gabaasa Karoora, Raawwii fi Parsentii (%) marsaa barnoota ammayyaa (1-6, 7-8, 1-8, 9-12 fi 1-12) wajjin.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse border border-slate-400">
              <thead className="bg-slate-800 text-white font-bold text-[11px] text-center">
                <tr>
                  <th className="border border-slate-400 p-2.5 text-left" rowSpan={2}>Kutaa / Ida'ama</th>
                  <th className="border border-slate-400 p-2 bg-indigo-950/60" colSpan={3}>Karoora (Target)</th>
                  <th className="border border-slate-400 p-2 bg-sky-950/60" colSpan={3}>Raawwii (Actual)</th>
                  <th className="border border-slate-400 p-2 bg-emerald-950/60" colSpan={3}>Raawwii Parsentii (%)</th>
                </tr>
                <tr className="bg-slate-700">
                  <th className="border border-slate-400 p-1.5">Dhiira</th>
                  <th className="border border-slate-400 p-1.5">Dhalaa</th>
                  <th className="border border-slate-400 p-1.5 font-bold">Total</th>
                  <th className="border border-slate-400 p-1.5">Dhiira</th>
                  <th className="border border-slate-400 p-1.5">Dhalaa</th>
                  <th className="border border-slate-400 p-1.5 font-bold">Total</th>
                  <th className="border border-slate-400 p-1.5 text-sky-200">Dhiira %</th>
                  <th className="border border-slate-400 p-1.5 text-rose-200">Dhalaa %</th>
                  <th className="border border-slate-400 p-1.5 font-bold text-emerald-200">Ida'ama %</th>
                </tr>
              </thead>
              <tbody>
                {structuredGradeStats.map((st) => (
                  <tr
                    key={st.key}
                    className={
                      st.isGrandTotal
                        ? 'bg-slate-900 text-white font-black'
                        : st.isSubtotal
                        ? 'bg-indigo-100/90 text-indigo-950 font-extrabold border-t-2 border-b-2 border-indigo-300'
                        : 'hover:bg-slate-50 font-medium'
                    }
                  >
                    <td
                      className={`border border-slate-400 p-2 font-black ${
                        st.isGrandTotal
                          ? 'text-amber-300 bg-slate-900'
                          : st.isSubtotal
                          ? 'text-indigo-950 bg-indigo-100'
                          : 'text-slate-900 bg-slate-100/60'
                      }`}
                    >
                      {st.kutaa}
                    </td>
                    <td className="border border-slate-400 p-2 text-center text-slate-700 font-mono font-bold">{st.targetDhiira}</td>
                    <td className="border border-slate-400 p-2 text-center text-slate-700 font-mono font-bold">{st.targetDhalaa}</td>
                    <td className="border border-slate-400 p-2 text-center font-bold text-indigo-900 bg-indigo-50/40">{st.targetTotal}</td>

                    <td className="border border-slate-400 p-2 text-center text-sky-700 font-bold">{st.dhiira}</td>
                    <td className="border border-slate-400 p-2 text-center text-rose-700 font-bold">{st.dhalaa}</td>
                    <td className="border border-slate-400 p-2 text-center font-bold text-slate-900 bg-sky-50/40">{st.total}</td>

                    <td className="border border-slate-400 p-2 text-center font-mono font-bold text-sky-800 bg-emerald-50/30">
                      {st.pctDhiira}%
                    </td>
                    <td className="border border-slate-400 p-2 text-center font-mono font-bold text-rose-800 bg-emerald-50/30">
                      {st.pctDhalaa}%
                    </td>
                    <td className="border border-slate-400 p-2 text-center font-mono font-black text-emerald-900 bg-emerald-100/50">
                      {st.pctTotal}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Age 7 Specific Breakdown Table in Tab I */}
          <div className="mt-8 pt-6 border-t-2 border-amber-300 space-y-3">
            <h4 className="text-md font-black text-amber-950 uppercase tracking-wide flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-600" />
                <span>Barattoota Umurii 7 Qofa (Kutaa 1 Karoora vs Raawwii)</span>
              </span>
              <span className="text-xs bg-amber-200 text-amber-950 px-3 py-1 rounded-full font-extrabold">
                Waliigala Umurii 7: {baseSchoolStudents.filter((s) => s.umurii === 7).length} Barattoota
              </span>
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse border border-amber-300">
                <thead className="bg-amber-100 text-amber-950 font-bold text-[11px] text-center">
                  <tr>
                    <th className="border border-amber-300 p-2 text-left">Kutaa (Umurii 7)</th>
                    <th className="border border-amber-300 p-2 bg-amber-200/60" colSpan={3}>Karoora (Target U7)</th>
                    <th className="border border-amber-300 p-2 bg-amber-300/60" colSpan={3}>Raawwii (Actual U7)</th>
                    <th className="border border-amber-300 p-2 bg-amber-400/80" colSpan={3}>Raawwii (%)</th>
                  </tr>
                  <tr className="bg-amber-50">
                    <th className="border border-amber-300 p-1.5">Dhiira</th>
                    <th className="border border-amber-300 p-1.5">Dhalaa</th>
                    <th className="border border-amber-300 p-1.5 font-bold">Total</th>
                    <th className="border border-amber-300 p-1.5">Dhiira</th>
                    <th className="border border-amber-300 p-1.5">Dhalaa</th>
                    <th className="border border-amber-300 p-1.5 font-bold">Total</th>
                    <th className="border border-amber-300 p-1.5 text-sky-900">Dhiira %</th>
                    <th className="border border-amber-300 p-1.5 text-rose-900">Dhalaa %</th>
                    <th className="border border-amber-300 p-1.5 font-bold text-amber-950">Ida'ama %</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-amber-200 font-medium">
                  {['1'].map((gStr) => {
                    const inGradeU7 = baseSchoolStudents.filter((s) => s.kutaa === gStr && s.umurii === 7);
                    const dhiira = inGradeU7.filter((s) => s.koorniyaa === 'Dhiira').length;
                    const dhalaa = inGradeU7.filter((s) => s.koorniyaa === 'Dhalaa').length;
                    const totalActual = dhiira + dhalaa;
                    const targetKey = `u7_${gStr}`;
                    const target = targets[targetKey] || { dhiira: 40, dhalaa: 35, kutaa: targetKey };
                    const targetTotal = target.dhiira + target.dhalaa;
                    const pctDhiira = target.dhiira > 0 ? ((dhiira / target.dhiira) * 100).toFixed(1) : '0.0';
                    const pctDhalaa = target.dhalaa > 0 ? ((dhalaa / target.dhalaa) * 100).toFixed(1) : '0.0';
                    const pctTotal = targetTotal > 0 ? ((totalActual / targetTotal) * 100).toFixed(1) : '0.0';

                    return (
                      <tr key={gStr} className="hover:bg-amber-50/80">
                        <td className="border border-amber-300 p-2 font-extrabold text-amber-950 bg-amber-50">
                          Kutaa {gStr} (Umurii 7)
                        </td>
                        <td className="border border-amber-300 p-2 text-center text-slate-700 font-mono font-bold">{target.dhiira}</td>
                        <td className="border border-amber-300 p-2 text-center text-slate-700 font-mono font-bold">{target.dhalaa}</td>
                        <td className="border border-amber-300 p-2 text-center font-bold text-amber-900 bg-amber-100/50">{targetTotal}</td>

                        <td className="border border-amber-300 p-2 text-center text-sky-700 font-bold">{dhiira}</td>
                        <td className="border border-amber-300 p-2 text-center text-rose-700 font-bold">{dhalaa}</td>
                        <td className="border border-amber-300 p-2 text-center font-bold text-slate-900 bg-amber-100/30">{totalActual}</td>

                        <td className="border border-amber-300 p-2 text-center font-mono font-bold text-sky-900">{pctDhiira}%</td>
                        <td className="border border-amber-300 p-2 text-center font-mono font-bold text-rose-900">{pctDhalaa}%</td>
                        <td className="border border-amber-300 p-2 text-center font-mono font-black text-amber-950 bg-amber-200/60">{pctTotal}%</td>
                      </tr>
                    );
                  })}

                  {/* Subtotal Age 7 */}
                  {(() => {
                    const allU7 = baseSchoolStudents.filter((s) => s.umurii === 7);
                    const totActDhiira = allU7.filter((s) => s.koorniyaa === 'Dhiira').length;
                    const totActDhalaa = allU7.filter((s) => s.koorniyaa === 'Dhalaa').length;
                    const totActual = allU7.length;

                    const totTgtDhiira = ['1'].reduce(
                      (acc, gStr) => acc + (targets[`u7_${gStr}`]?.dhiira || 40),
                      0
                    );
                    const totTgtDhalaa = ['1'].reduce(
                      (acc, gStr) => acc + (targets[`u7_${gStr}`]?.dhalaa || 35),
                      0
                    );
                    const totTgt = totTgtDhiira + totTgtDhalaa;

                    const pctDhiira = totTgtDhiira > 0 ? ((totActDhiira / totTgtDhiira) * 100).toFixed(1) : '0.0';
                    const pctDhalaa = totTgtDhalaa > 0 ? ((totActDhalaa / totTgtDhalaa) * 100).toFixed(1) : '0.0';
                    const pctTotal = totTgt > 0 ? ((totActual / totTgt) * 100).toFixed(1) : '0.0';

                    return (
                      <tr className="bg-amber-300 text-amber-950 font-black text-xs">
                        <td className="border border-amber-400 p-2.5">WALIIGALA BARATTOOTA UMURII 7 (KUTAA 1)</td>
                        <td className="border border-amber-400 p-2 text-center font-mono">{totTgtDhiira}</td>
                        <td className="border border-amber-400 p-2 text-center font-mono">{totTgtDhalaa}</td>
                        <td className="border border-amber-400 p-2 text-center font-mono">{totTgt}</td>

                        <td className="border border-amber-400 p-2 text-center font-mono">{totActDhiira}</td>
                        <td className="border border-amber-400 p-2 text-center font-mono">{totActDhalaa}</td>
                        <td className="border border-amber-400 p-2 text-center font-mono">{totActual}</td>

                        <td className="border border-amber-400 p-2 text-center font-mono">{pctDhiira}%</td>
                        <td className="border border-amber-400 p-2 text-center font-mono">{pctDhalaa}%</td>
                        <td className="border border-amber-400 p-2 text-center font-mono">{pctTotal}%</td>
                      </tr>
                    );
                  })()}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Student, GradeTarget, LoginRecord, SchoolSettings, EMISStudent } from './types';
import {
  getStoredStudents,
  saveStoredStudents,
  getStoredTargets,
  saveStoredTargets,
  getStoredLogins,
  addLoginRecord,
  deleteLoginRecord,
  getStoredSettings,
  saveStoredSettings,
  getStoredCurrentUser,
  setStoredCurrentUser,
  getStoredEMISRecords,
  saveStoredEMISRecords,
  getStoredRevokedUsers,
  getStoredAuthorizedUsers,
} from './utils/storage';
import { LoginModal } from './components/LoginModal';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { BuuuraBoruuDashboard } from './components/BuuuraBoruuDashboard';
import { StudentRegistration } from './components/StudentRegistration';
import { GradeTargets } from './components/GradeTargets';
import { EMISUpload } from './components/EMISUpload';
import { Reports } from './components/Reports';
import { Settings } from './components/Settings';
import { AdminLevelsDashboard } from './components/AdminLevelsDashboard';
import { PwaInstallBanner } from './components/PwaInstallBanner';
import { AppPostcardModal } from './components/AppPostcardModal';

export default function App() {
  const [currentUser, setCurrentUser] = useState<string | null>(getStoredCurrentUser());
  const [revokedMessage, setRevokedMessage] = useState<string>('');
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedSchoolFilter, setSelectedSchoolFilter] = useState<string>('ALL_WOREDA');
  const [isAdminUnlocked, setIsAdminUnlocked] = useState<boolean>(false);
  const [showPostcardModal, setShowPostcardModal] = useState<boolean>(false);

  // Instant revocation monitor
  useEffect(() => {
    if (!currentUser) return;
    const cleanCurrent = currentUser.trim().toLowerCase();
    if (cleanCurrent === 'kitesanegasa2012@gmail.com') return;

    const verifyUserPermission = () => {
      const revoked = getStoredRevokedUsers();
      const authorized = getStoredAuthorizedUsers();
      const isRevoked = revoked.includes(cleanCurrent);
      const isStillAuth = !!authorized[cleanCurrent];

      if (isRevoked || !isStillAuth) {
        setCurrentUser(null);
        setStoredCurrentUser(null);
        setRevokedMessage('Dhiifama yeroof Eeyyamni keessan haqameera');
      }
    };

    verifyUserPermission();
    const timer = setInterval(verifyUserPermission, 1000);
    window.addEventListener('storage', verifyUserPermission);
    window.addEventListener('focus', verifyUserPermission);

    return () => {
      clearInterval(timer);
      window.removeEventListener('storage', verifyUserPermission);
      window.removeEventListener('focus', verifyUserPermission);
    };
  }, [currentUser]);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  // State
  const [students, setStudents] = useState<Student[]>([]);
  const [targets, setTargets] = useState<Record<string, GradeTarget>>({});
  const [loginHistory, setLoginHistory] = useState<LoginRecord[]>([]);
  const [settings, setSettings] = useState<SchoolSettings>(getStoredSettings());
  const [emisRecords, setEmisRecords] = useState<EMISStudent[]>([]);

  const handleRefreshData = () => {
    setStudents(getStoredStudents());
    setTargets(getStoredTargets());
    setLoginHistory(getStoredLogins());
    setSettings(getStoredSettings());
    setEmisRecords(getStoredEMISRecords());
  };

  useEffect(() => {
    handleRefreshData();
  }, []);

  const handleSaveEmisRecords = (newRecords: EMISStudent[]) => {
    setEmisRecords(newRecords);
    saveStoredEMISRecords(newRecords);
  };

  // Save changes
  const handleAddStudent = (newStudent: Student) => {
    const updated = [newStudent, ...students];
    setStudents(updated);
    saveStoredStudents(updated);
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    const updated = students.map((s) => (s.id === updatedStudent.id ? updatedStudent : s));
    setStudents(updated);
    saveStoredStudents(updated);
  };

  const handleDeleteStudent = (id: string) => {
    const updated = students.filter((s) => s.id !== id);
    setStudents(updated);
    saveStoredStudents(updated);
  };

  const handleDeleteStudentsByIDs = (ids: string[]) => {
    const idSet = new Set(ids);
    const updated = students.filter((s) => !idSet.has(s.id));
    setStudents(updated);
    saveStoredStudents(updated);
  };

  const handleAddMultipleStudents = (newStudents: Student[]) => {
    const cleanName = (n: string) => (n || '').trim().replace(/\s+/g, ' ').toLowerCase();
    const currentList = [...students];

    newStudents.forEach((incoming) => {
      const idx = currentList.findIndex((existing) => {
        if (incoming.id && existing.id && incoming.id === existing.id) return true;
        if (incoming.nationalId && existing.nationalId && incoming.nationalId !== '-' && incoming.nationalId === existing.nationalId) return true;
        if (incoming.fanId && existing.fanId && incoming.fanId !== 'NO' && incoming.fanId === existing.fanId) return true;
        if (cleanName(incoming.maqaaGuutuu) === cleanName(existing.maqaaGuutuu)) return true;
        return false;
      });

      if (idx !== -1) {
        currentList[idx] = {
          ...currentList[idx],
          ...incoming,
          id: currentList[idx].id,
          fanId: (incoming.fanId && incoming.fanId !== 'NO') ? incoming.fanId : currentList[idx].fanId,
          nationalId: (incoming.nationalId && incoming.nationalId !== '-') ? incoming.nationalId : currentList[idx].nationalId,
          avireejjiiQabxii: (incoming.avireejjiiQabxii !== undefined && incoming.avireejjiiQabxii !== 'NO') ? incoming.avireejjiiQabxii : currentList[idx].avireejjiiQabxii,
          kutaa: (incoming.kutaa && incoming.kutaa !== '1') ? incoming.kutaa : currentList[idx].kutaa,
        };
      } else {
        currentList.push(incoming);
      }
    });

    setStudents(currentList);
    saveStoredStudents(currentList);
  };

  const handleUpdateMultipleStudents = (updatedStudents: Student[]) => {
    const updateMap = new Map(updatedStudents.map((s) => [s.id, s]));
    const updated = students.map((s) => updateMap.get(s.id) || s);
    setStudents(updated);
    saveStoredStudents(updated);
  };

  const handleSaveTargets = (newTargets: Record<string, GradeTarget>) => {
    setTargets(newTargets);
    saveStoredTargets(newTargets);
  };

  const handleSaveSettings = (newSettings: SchoolSettings) => {
    setSettings(newSettings);
    saveStoredSettings(newSettings);
  };

  const handleDeleteLogin = (id: string) => {
    const updated = deleteLoginRecord(id);
    setLoginHistory(updated);
  };

  const handleDeleteSchoolData = (schoolName: string) => {
    const updated = students.filter((s) => s.manaBarumsaa !== schoolName);
    setStudents(updated);
    saveStoredStudents(updated);
  };

  const handleLoginSuccess = (userEmail: string) => {
    setRevokedMessage('');
    setCurrentUser(userEmail);
    setStoredCurrentUser(userEmail);
    const updatedLogins = addLoginRecord(userEmail);
    setLoginHistory(updatedLogins);
    setShowPostcardModal(true);
  };

  const handleLogout = () => {
    setRevokedMessage('');
    setCurrentUser(null);
    setStoredCurrentUser(null);
  };

  // List of distinct school names
  const allSchools = Array.from(
    new Set(students.map((s) => s.manaBarumsaa).filter((s) => s && s.trim() !== ''))
  );

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-100 flex flex-col justify-between">
        <PwaInstallBanner />
        <LoginModal onLoginSuccess={handleLoginSuccess} revokedMessage={revokedMessage} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans flex flex-col justify-between">
      <div>
        <PwaInstallBanner />
        {/* Navigation Header */}
        <Navbar
          activeTab={activeTab}
          setActiveTab={handleTabChange}
          currentUser={currentUser}
          onLogout={handleLogout}
          settings={settings}
          selectedSchoolFilter={selectedSchoolFilter}
          onOpenPostcard={() => setShowPostcardModal(true)}
        />

        {/* Main Workspace Body */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {activeTab === 'dashboard' && (
            <Dashboard
              students={students}
              targets={targets}
              settings={settings}
              onNavigate={setActiveTab}
              allSchools={allSchools}
              selectedSchoolFilter={selectedSchoolFilter}
              onSelectSchoolFilter={setSelectedSchoolFilter}
              onOpenPostcard={() => setShowPostcardModal(true)}
            />
          )}

          {activeTab === 'aanaa' && (
            <AdminLevelsDashboard
              students={students}
              targets={targets}
              settings={settings}
              emisRecords={emisRecords}
              level="aanaa"
              onNavigate={setActiveTab}
              isUnlocked={isAdminUnlocked}
              onUnlockSuccess={() => setIsAdminUnlocked(true)}
            />
          )}

          {activeTab === 'godina' && (
            <AdminLevelsDashboard
              students={students}
              targets={targets}
              settings={settings}
              emisRecords={emisRecords}
              level="godina"
              onNavigate={setActiveTab}
              isUnlocked={isAdminUnlocked}
              onUnlockSuccess={() => setIsAdminUnlocked(true)}
            />
          )}

          {activeTab === 'oromiyaa' && (
            <AdminLevelsDashboard
              students={students}
              targets={targets}
              settings={settings}
              emisRecords={emisRecords}
              level="oromiyaa"
              onNavigate={setActiveTab}
              isUnlocked={isAdminUnlocked}
              onUnlockSuccess={() => setIsAdminUnlocked(true)}
            />
          )}

          {activeTab === 'buuura_boruu' && (
            <BuuuraBoruuDashboard
              students={students}
              emisRecords={emisRecords}
              settings={settings}
              onNavigate={setActiveTab}
              allSchools={allSchools}
            />
          )}

          {activeTab === 'students' && (
            <StudentRegistration
              students={students}
              emisRecords={emisRecords}
              onAddStudent={handleAddStudent}
              onUpdateStudent={handleUpdateStudent}
              onDeleteStudent={handleDeleteStudent}
              settings={settings}
              currentUser={currentUser}
            />
          )}

          {activeTab === 'targets' && (
            <GradeTargets
              students={students}
              targets={targets}
              onSaveTargets={handleSaveTargets}
            />
          )}

          {activeTab === 'emis' && (
            <EMISUpload
              appStudents={students}
              emisRecords={emisRecords}
              onSaveEmisRecords={handleSaveEmisRecords}
              onAddMultipleStudents={handleAddMultipleStudents}
              onUpdateMultipleStudents={handleUpdateMultipleStudents}
              onDeleteStudentsByIDs={handleDeleteStudentsByIDs}
            />
          )}

          {activeTab === 'reports' && (
            <Reports
              students={students}
              targets={targets}
              onSaveTargets={handleSaveTargets}
              settings={settings}
            />
          )}

          {activeTab === 'settings' && (
            <Settings
              settings={settings}
              onSaveSettings={handleSaveSettings}
              loginHistory={loginHistory}
              onDeleteLogin={handleDeleteLogin}
              allSchools={allSchools}
              onDeleteSchoolData={handleDeleteSchoolData}
              onRefreshData={handleRefreshData}
            />
          )}
        </main>
      </div>

      {/* Global Footer */}
      <footer className="bg-slate-900 text-slate-400 py-6 text-center text-xs border-t border-slate-800 print:hidden mt-12">
        <div className="max-w-7xl mx-auto px-4 space-y-1">
          <p className="font-semibold text-slate-200">
            Kitesa Negasa Feyisa — Student Registration System (Systema Galmee Barattootaa)
          </p>
          <p>
            Phone & Telegram: <span className="text-amber-400 font-mono">+251969184005</span> / <span className="text-amber-400 font-mono">0910927936</span> | Gmail: <span className="text-rose-400">kitesanegasa2012@gmail.com</span>
          </p>
          <p className="text-[10px] text-slate-500 pt-2">
            © {new Date().getFullYear()} All rights reserved. Built with React, TypeScript & Tailwind CSS.
          </p>
        </div>
      </footer>
      {/* Postcard Overview Modal */}
      <AppPostcardModal
        isOpen={showPostcardModal}
        onClose={() => setShowPostcardModal(false)}
        onNavigateTab={(tabId) => {
          setActiveTab(tabId);
          setShowPostcardModal(false);
        }}
      />
    </div>
  );
}
